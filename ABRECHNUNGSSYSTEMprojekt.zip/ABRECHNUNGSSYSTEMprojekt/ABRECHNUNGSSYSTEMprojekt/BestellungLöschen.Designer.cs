﻿
namespace ABRECHNUNGSSYSTEMprojekt
{
    partial class BestellungLöschen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgentfernen = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgentfernen)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgentfernen);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1051, 320);
            this.panel1.TabIndex = 0;
            // 
            // dgentfernen
            // 
            this.dgentfernen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dgentfernen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgentfernen.Location = new System.Drawing.Point(3, 0);
            this.dgentfernen.Name = "dgentfernen";
            this.dgentfernen.RowHeadersWidth = 51;
            this.dgentfernen.Size = new System.Drawing.Size(1045, 320);
            this.dgentfernen.TabIndex = 0;
            this.dgentfernen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgentfernen_CellDoubleClick);
            // 
            // BestellungLöschen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1044, 694);
            this.Controls.Add(this.panel1);
            this.Name = "BestellungLöschen";
            this.Text = "BestellungLöschen";
            this.Load += new System.EventHandler(this.BestellungLöschen_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgentfernen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgentfernen;
    }
}