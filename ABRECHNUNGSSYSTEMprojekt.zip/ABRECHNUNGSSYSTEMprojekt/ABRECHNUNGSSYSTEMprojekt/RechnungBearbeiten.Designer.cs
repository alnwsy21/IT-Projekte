﻿
namespace ABRECHNUNGSSYSTEMprojekt
{
    partial class RechnungBearbeiten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgbearbeiten = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.tbx_datum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbx_lieferung = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbx_betrag = new System.Windows.Forms.TextBox();
            this.cbx_konto = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbx_mwst = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbx_status = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbx_zahlung = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbx_bestellung = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbx_versand = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgbearbeiten);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1042, 196);
            this.panel1.TabIndex = 0;
            // 
            // dgbearbeiten
            // 
            this.dgbearbeiten.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dgbearbeiten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbearbeiten.Location = new System.Drawing.Point(0, -1);
            this.dgbearbeiten.Name = "dgbearbeiten";
            this.dgbearbeiten.RowHeadersWidth = 51;
            this.dgbearbeiten.Size = new System.Drawing.Size(1042, 198);
            this.dgbearbeiten.TabIndex = 0;
            this.dgbearbeiten.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbearbeiten_CellDoubleClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(620, 433);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 25);
            this.label14.TabIndex = 87;
            this.label14.Text = "Datum:";
            // 
            // tbx_datum
            // 
            this.tbx_datum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_datum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_datum.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_datum.Location = new System.Drawing.Point(837, 433);
            this.tbx_datum.Multiline = true;
            this.tbx_datum.Name = "tbx_datum";
            this.tbx_datum.Size = new System.Drawing.Size(173, 27);
            this.tbx_datum.TabIndex = 86;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(620, 378);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 25);
            this.label13.TabIndex = 85;
            this.label13.Text = "Lieferung:";
            // 
            // tbx_lieferung
            // 
            this.tbx_lieferung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_lieferung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_lieferung.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_lieferung.Location = new System.Drawing.Point(837, 378);
            this.tbx_lieferung.Multiline = true;
            this.tbx_lieferung.Name = "tbx_lieferung";
            this.tbx_lieferung.Size = new System.Drawing.Size(173, 27);
            this.tbx_lieferung.TabIndex = 84;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gainsboro;
            this.label12.Location = new System.Drawing.Point(620, 326);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 25);
            this.label12.TabIndex = 83;
            this.label12.Text = "Betrag:";
            // 
            // tbx_betrag
            // 
            this.tbx_betrag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_betrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_betrag.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_betrag.Location = new System.Drawing.Point(837, 326);
            this.tbx_betrag.Multiline = true;
            this.tbx_betrag.Name = "tbx_betrag";
            this.tbx_betrag.Size = new System.Drawing.Size(173, 27);
            this.tbx_betrag.TabIndex = 82;
            // 
            // cbx_konto
            // 
            this.cbx_konto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_konto.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_konto.FormattingEnabled = true;
            this.cbx_konto.Location = new System.Drawing.Point(837, 267);
            this.cbx_konto.Name = "cbx_konto";
            this.cbx_konto.Size = new System.Drawing.Size(173, 21);
            this.cbx_konto.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(620, 267);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 25);
            this.label11.TabIndex = 80;
            this.label11.Text = "Konto ID:";
            // 
            // cbx_mwst
            // 
            this.cbx_mwst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_mwst.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_mwst.FormattingEnabled = true;
            this.cbx_mwst.Location = new System.Drawing.Point(261, 491);
            this.cbx_mwst.Name = "cbx_mwst";
            this.cbx_mwst.Size = new System.Drawing.Size(173, 21);
            this.cbx_mwst.TabIndex = 77;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(21, 491);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(177, 25);
            this.label10.TabIndex = 76;
            this.label10.Text = "Mehrwertsteuer ID:";
            // 
            // cbx_status
            // 
            this.cbx_status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_status.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_status.FormattingEnabled = true;
            this.cbx_status.Location = new System.Drawing.Point(261, 407);
            this.cbx_status.Name = "cbx_status";
            this.cbx_status.Size = new System.Drawing.Size(173, 21);
            this.cbx_status.TabIndex = 73;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(21, 407);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 25);
            this.label8.TabIndex = 72;
            this.label8.Text = "Status ID:";
            // 
            // cbx_zahlung
            // 
            this.cbx_zahlung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_zahlung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_zahlung.FormattingEnabled = true;
            this.cbx_zahlung.Location = new System.Drawing.Point(261, 332);
            this.cbx_zahlung.Name = "cbx_zahlung";
            this.cbx_zahlung.Size = new System.Drawing.Size(173, 21);
            this.cbx_zahlung.TabIndex = 69;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(21, 332);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 25);
            this.label7.TabIndex = 68;
            this.label7.Text = "Zahlung ID:";
            // 
            // cbx_bestellung
            // 
            this.cbx_bestellung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_bestellung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_bestellung.FormattingEnabled = true;
            this.cbx_bestellung.Location = new System.Drawing.Point(837, 224);
            this.cbx_bestellung.Name = "cbx_bestellung";
            this.cbx_bestellung.Size = new System.Drawing.Size(173, 21);
            this.cbx_bestellung.TabIndex = 67;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(620, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 25);
            this.label3.TabIndex = 66;
            this.label3.Text = "Bestellung ID:";
            // 
            // cbx_versand
            // 
            this.cbx_versand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_versand.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_versand.FormattingEnabled = true;
            this.cbx_versand.Location = new System.Drawing.Point(261, 230);
            this.cbx_versand.Name = "cbx_versand";
            this.cbx_versand.Size = new System.Drawing.Size(173, 21);
            this.cbx_versand.TabIndex = 61;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(21, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 60;
            this.label1.Text = "Versand ID:";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(261, 618);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(749, 51);
            this.button1.TabIndex = 88;
            this.button1.Text = "Speichern";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RechnungBearbeiten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1044, 696);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbx_datum);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tbx_lieferung);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbx_betrag);
            this.Controls.Add(this.cbx_konto);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbx_mwst);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cbx_status);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbx_zahlung);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cbx_bestellung);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbx_versand);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "RechnungBearbeiten";
            this.Text = "RechnungBearbeiten";
            this.Load += new System.EventHandler(this.RechnungBearbeiten_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgbearbeiten;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbx_datum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbx_lieferung;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbx_betrag;
        private System.Windows.Forms.ComboBox cbx_konto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbx_mwst;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbx_status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbx_zahlung;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbx_bestellung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_versand;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}