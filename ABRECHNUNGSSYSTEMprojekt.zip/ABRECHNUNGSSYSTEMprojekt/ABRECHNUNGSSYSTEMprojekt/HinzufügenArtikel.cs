﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class HinzufügenArtikel : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public HinzufügenArtikel() {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e) {

        }

        private void HinzufügenArtikel_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten


                cmd = new OleDbCommand("select * from ArtikelGruppe order by Artikelgruppe_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {

                    cbx_gruppen_id.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Kasse order by Kassen_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read()) {

                   cbx_kasse_id.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try {
                using (OleDbConnection con = new OleDbConnection(connectionString)) {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_gruppen_id.Text) || string.IsNullOrWhiteSpace(tbx_art_bez.Text)
                        || string.IsNullOrWhiteSpace(cbx_kasse_id.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text) || string.IsNullOrWhiteSpace(tbx_preis.Text)) {

                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else {
                        using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Artikel (Gruppen_id, Artikel_bezeichnung, Menge, Artikel_preis, Kassen_id) " +
                            "VALUES (@grpid, @artbez, @menge, @artpreis, @kasseid)", con)) {

                            insertCmd.Parameters.AddWithValue("@grpid", Convert.ToInt32(cbx_gruppen_id.Text));
                            insertCmd.Parameters.AddWithValue("@artbez", tbx_art_bez.Text);
                            insertCmd.Parameters.AddWithValue("@menge", tbx_menge.Text);
                            insertCmd.Parameters.AddWithValue("@artpreis", tbx_preis.Text);
                            insertCmd.Parameters.AddWithValue("@kasseid", Convert.ToInt32(cbx_kasse_id.Text)); 
                     
                            insertCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");
                    }
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex);
            }
        }

        private void cbx_gruppen_id_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_gruppen_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from ArtikelGruppe where Artikelgruppe_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_grp_bezeichnung.Text = dr.GetString(1);

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_kasse_id_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_kasse_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Kasse where Kassen_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_kasse_adresse.Text = dr.GetString(1);

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }
    }
}
