﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class BestellungHinzufügen : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        public BestellungHinzufügen()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void BestellungHinzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Datenbank-öffnungsfehler: " + ex.Message);
            }

            FillComboBoxes();
            PopulateDataGridView();
            AdjustDataGridViewSize();
        }

        private void FillComboBoxes()
        {
            try
            {
                con.Open();

                FillComboBoxFromQuery("SELECT Kunden_id FROM Kunde ORDER BY Kunden_id ASC", cbx_kunden);
                FillComboBoxFromQuery("SELECT Zahlung_id FROM ZahlungArt ORDER BY Zahlung_id ASC", cbx_zahlung);
                FillComboBoxFromQuery("SELECT Konto_id FROM Konto ORDER BY Konto_id ASC", cbx_konto);

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Zugriff auf die Tabellen: " + ex.Message);
            }
        }


        private void FillComboBoxFromQuery(string query, ComboBox comboBox)
        {
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            dr.Close();
        }

        private void PopulateDataGridView()
        {
            try
            {
                con.Open();
                ds.Clear();

                // Ändere die Reihenfolge der Abfrage, um die neuesten Einträge zuerst zu erhalten
                ada = new OleDbDataAdapter("SELECT Bestellung_id, Bestellung_datum, Kunden_id, Zahlung_id, Konto_id FROM Bestellung ORDER BY Bestellung_id ASC", con);
                ada.Fill(ds, "Bestellung");

                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Bestellung";

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }

        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dghinzufügen.AllowUserToAddRows = false;
            dghinzufügen.AllowUserToDeleteRows = false;
            dghinzufügen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dghinzufügen.RowHeadersVisible = false;
            dghinzufügen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dghinzufügen.MultiSelect = false;
            dghinzufügen.ReadOnly = true;
            dghinzufügen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dghinzufügen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.DefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dghinzufügen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dghinzufügen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dghinzufügen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dghinzufügen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dghinzufügen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dghinzufügen.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dghinzufügen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dghinzufügen.Location = new Point(10, 10);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungBestellposition());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_kunden.Text) || string.IsNullOrWhiteSpace(cbx_konto.Text) || string.IsNullOrWhiteSpace(cbx_zahlung.Text)
                        || string.IsNullOrWhiteSpace(tbx_datum.Text))
                    {
                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Bestellung (Bestellung_datum, Kunden_id, Zahlung_id, Konto_id) " +
                            "VALUES (@datum, @Kunden, @zahlung, @konto)", con))
                        {
                            insertCmd.Parameters.AddWithValue("@datum", tbx_datum.Text);
                            insertCmd.Parameters.AddWithValue("@Kunden", Convert.ToInt32(cbx_kunden.Text));
                            insertCmd.Parameters.AddWithValue("@zahlung", Convert.ToInt32(cbx_zahlung.Text));
                            insertCmd.Parameters.AddWithValue("@konto", Convert.ToInt32(cbx_konto.Text));

                            insertCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        // Nach dem Einfügen der Bestellung die DataGridView aktualisieren
                        PopulateDataGridView();
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message);
            }
        }
    }
}
