﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class Mitarbeiterverwaltung : Form {
        OleDbCommand cmd = new OleDbCommand();
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Mitarbeiterverwaltung() {
            InitializeComponent();
            //customsizedesign();
        }
        private void customsizedesign() {
            Verwaltung.Visible = false;

        }
        private void hidesubmenu() {
            if (Verwaltung.Visible == true) {
                Verwaltung.Visible = false;
            }
        }
        private void showsubmenu(Panel submenu) {
            if (submenu.Visible == false) {
                hidesubmenu();
                submenu.Visible = true;
            }
            else {
                submenu.Visible = false;
            }
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void bildname_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e) {
            //showsubmenu(Verwaltung);
        }

        private void button1_Click(object sender, EventArgs e) {
            openchildform(new MitarbeiterAnzeigen());
        }

        private void button2_Click(object sender, EventArgs e) {
            openchildform(new MitarbeiterHInzufügen());
        }

        private void Mitarbeiterverwaltung_Load(object sender, EventArgs e) {
       
        }

        private void button3_Click(object sender, EventArgs e) {
            openchildform(new MitarbeiterBearbeiten());
        }

        private void button4_Click(object sender, EventArgs e) {
            openchildform(new Mitarbeiterentfernen());        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
        
        }

        private void btn_anzeigen_MouseLeave(object sender, EventArgs e)
        {
          
        }
    }
}
