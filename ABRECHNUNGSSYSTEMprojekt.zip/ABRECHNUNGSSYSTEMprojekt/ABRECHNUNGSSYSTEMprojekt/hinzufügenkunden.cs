﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class hinzufügenkunden : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        public hinzufügenkunden() {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) {

        }

        private void hinzufügenkunden_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }


            try {
                //der tabelname das kein - enthalten


                cmd = new OleDbCommand("select * from ZahlungArt order by Zahlung_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {

                    cbx_zahl.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Rabatt order by Rabatt_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read()) {

                    cbx_rabatt.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
            tbx_password.PasswordChar = '•'; // oder textBox1.PasswordChar = '.';
        }

        private void button1_Click(object sender, EventArgs e) {
                try {
                    using (OleDbConnection con = new OleDbConnection(connectionString)) {
                        con.Open();
                        if (string.IsNullOrWhiteSpace(tbx_vorname.Text) || string.IsNullOrWhiteSpace(tbx_nachname.Text)
                            || string.IsNullOrWhiteSpace(tbx_punkte.Text) || string.IsNullOrWhiteSpace(tbx_benutzername.Text) || string.IsNullOrWhiteSpace(tbx_password.Text)
                            || string.IsNullOrWhiteSpace(cbx_zahl.Text) || string.IsNullOrWhiteSpace(cbx_rabatt.Text)) {

                            MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else {
                            using (OleDbCommand insertCmd = new OleDbCommand
                            ("INSERT INTO Kunde(Zahlung_id, Kunden_vorname, Kunden_nachname, Kunden_adresse, Kunden_benutzername, Kunden_password, Rabatt_id, Punkte) " +
                                "VALUES (@Zahlung, @vorname, @nachname, @adresse, @benutzername, @passwort, @Rabatt, @Punkte)", con)) {

                                insertCmd.Parameters.AddWithValue("@Zahlung", Convert.ToInt32(cbx_zahl.Text));
                                insertCmd.Parameters.AddWithValue("@vorname", tbx_vorname.Text);
                                insertCmd.Parameters.AddWithValue("@nachname", tbx_nachname.Text);
                                insertCmd.Parameters.AddWithValue("@adresse", tbx_adresse.Text);
                                insertCmd.Parameters.AddWithValue("@benutzername", tbx_benutzername.Text);
                                insertCmd.Parameters.AddWithValue("@passwort", tbx_password.Text); // Korrigiertes Passwort 
                                insertCmd.Parameters.AddWithValue("@Rabatt", Convert.ToInt32(cbx_rabatt.Text));
                                insertCmd.Parameters.AddWithValue("@Punkte", Convert.ToInt32(tbx_punkte.Text));
                                insertCmd.ExecuteNonQuery();
                            }
                            MessageBox.Show("Erfolgreich");
                        }
                    }
                }
                catch (Exception ex) {
                    // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                    MessageBox.Show("Fehler beim Speichern der Daten: " + ex);
                }

        }

        private void cbx_zahl_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_zahl.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from ZahlungArt where Zahlung_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_name.Text = dr.GetString(1);

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }
    }
}
