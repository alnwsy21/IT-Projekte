﻿
namespace ABRECHNUNGSSYSTEMprojekt
{
    partial class BestellungHinzufügen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.panelchildform = new System.Windows.Forms.Panel();
            this.tbx_datum = new System.Windows.Forms.TextBox();
            this.cbx_konto = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbx_zahlung = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbx_kunden = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.panelchildform.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dghinzufügen.Location = new System.Drawing.Point(-3, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1046, 161);
            this.dghinzufügen.TabIndex = 0;
            // 
            // panelchildform
            // 
            this.panelchildform.Controls.Add(this.panel1);
            this.panelchildform.Controls.Add(this.tbx_datum);
            this.panelchildform.Controls.Add(this.cbx_konto);
            this.panelchildform.Controls.Add(this.label5);
            this.panelchildform.Controls.Add(this.cbx_zahlung);
            this.panelchildform.Controls.Add(this.label3);
            this.panelchildform.Controls.Add(this.cbx_kunden);
            this.panelchildform.Controls.Add(this.label2);
            this.panelchildform.Controls.Add(this.label1);
            this.panelchildform.Controls.Add(this.button2);
            this.panelchildform.Controls.Add(this.button1);
            this.panelchildform.Location = new System.Drawing.Point(-2, -1);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1046, 695);
            this.panelchildform.TabIndex = 37;
            // 
            // tbx_datum
            // 
            this.tbx_datum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_datum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_datum.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_datum.Location = new System.Drawing.Point(400, 208);
            this.tbx_datum.Multiline = true;
            this.tbx_datum.Name = "tbx_datum";
            this.tbx_datum.Size = new System.Drawing.Size(173, 29);
            this.tbx_datum.TabIndex = 52;
            // 
            // cbx_konto
            // 
            this.cbx_konto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cbx_konto.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_konto.FormattingEnabled = true;
            this.cbx_konto.Location = new System.Drawing.Point(400, 467);
            this.cbx_konto.Name = "cbx_konto";
            this.cbx_konto.Size = new System.Drawing.Size(173, 21);
            this.cbx_konto.TabIndex = 51;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(208, 465);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 20);
            this.label5.TabIndex = 50;
            this.label5.Text = "Konto ID:";
            // 
            // cbx_zahlung
            // 
            this.cbx_zahlung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cbx_zahlung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_zahlung.FormattingEnabled = true;
            this.cbx_zahlung.Location = new System.Drawing.Point(400, 376);
            this.cbx_zahlung.Name = "cbx_zahlung";
            this.cbx_zahlung.Size = new System.Drawing.Size(173, 21);
            this.cbx_zahlung.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(208, 374);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 20);
            this.label3.TabIndex = 48;
            this.label3.Text = "Zahlung ID:";
            // 
            // cbx_kunden
            // 
            this.cbx_kunden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cbx_kunden.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_kunden.FormattingEnabled = true;
            this.cbx_kunden.Location = new System.Drawing.Point(400, 293);
            this.cbx_kunden.Name = "cbx_kunden";
            this.cbx_kunden.Size = new System.Drawing.Size(173, 21);
            this.cbx_kunden.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(208, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 46;
            this.label2.Text = "Kunden ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(208, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 44;
            this.label1.Text = "Bestellung Datum:";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Gainsboro;
            this.button2.Location = new System.Drawing.Point(212, 632);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(546, 51);
            this.button2.TabIndex = 43;
            this.button2.Text = "Speichern";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(869, 632);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 51);
            this.button1.TabIndex = 38;
            this.button1.Text = "Nächste Seite";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dghinzufügen);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1043, 164);
            this.panel1.TabIndex = 53;
            // 
            // BestellungHinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1044, 694);
            this.Controls.Add(this.panelchildform);
            this.Name = "BestellungHinzufügen";
            this.Text = "BestellungHinzufügen";
            this.Load += new System.EventHandler(this.BestellungHinzufügen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbx_konto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbx_zahlung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_kunden;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbx_datum;
        private System.Windows.Forms.Panel panel1;
    }
}