﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class Login : Form {
        private OleDbConnection verbindung;
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        public Login() {
            InitializeComponent();
            tbx_password.KeyPress += TbxPassword_KeyPress;
            verbindung = new OleDbConnection(connectionString);
        }
        private void TbxPassword_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                // Hier kannst du den Code ausführen, den du beim Drücken der Enter-Taste machen möchtest
                // Zum Beispiel den Button-Klick auslösen
                btn_login.PerformClick();

                // Verhindere, dass das Zeichen in der TextBox angezeigt wird
                e.Handled = true;
            }
        }
        private void Login_Load(object sender, EventArgs e) {
            tbx_password.PasswordChar = '•'; // oder textBox1.PasswordChar = '.';
        }

        private void cbx_show_CheckedChanged(object sender, EventArgs e) {
            if (cbx_show.Checked && tbx_show.Visible == false) {
                tbx_show.PasswordChar = '\0'; // Zeigt den Text in tbx_show sichtbar
                tbx_show.Visible = true;
            }
            else {
                tbx_show.PasswordChar = '•'; // Verdeckt den Text in tbx_show
                tbx_show.Visible = false;
            }
        }

        private void tbx_password_TextChanged(object sender, EventArgs e) {
            tbx_show.Text = tbx_password.Text;
        }

        private void button1_Click(object sender, EventArgs e) {
            tbx_password.Clear();
            tbx_name.Clear();
            tbx_show.Clear();
            cbx_show.Checked = false;
            bildname.Visible = false;
            bildpassword.Visible = false;
        }

        private void btn_login_Click(object sender, EventArgs e) {
            string benutzername = tbx_name.Text;
            string passwort = tbx_password.Text;

            if (ÜberprüfeAnmeldung(benutzername, passwort)) {
                // Anmeldung erfolgreich, öffnen Sie Ihr anderes Fenster
                // Zum Beispiel ein Hauptfenster (MainForm) oder ein Dashboard-Fenster


                Hauptmenü haupt = new Hauptmenü(benutzername, passwort);
                haupt.ShowDialog();
                // Schließen Sie das Anmeldeformular
                tbx_password.Clear();
                tbx_name.Clear();
             
            }
            else {
                fehlermeldung();
                MessageBox.Show("Anmeldung fehlgeschlagen! Versuchen sie erneut!");
            }
        }

        private bool ÜberprüfeAnmeldung(string benutzername, string passwort) {
            using (OleDbConnection verbindung = new OleDbConnection(connectionString)) {
                // ... andere Code ...
                try {
                    verbindung.Open();
                    OleDbCommand befehl = new OleDbCommand("SELECT Benutzername FROM Mitarbeiter WHERE Benutzername = @Benutzername AND Passwort = @Passwort", verbindung);
                    befehl.Parameters.AddWithValue("@Benutzername", benutzername);
                    befehl.Parameters.AddWithValue("@Passwort", passwort);
                    OleDbDataReader leser = befehl.ExecuteReader();

                    if (leser.HasRows) {
                        leser.Close();
                        verbindung.Close();
                        return true;
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show("Fehler bei der Anmeldung: " + ex.Message);
                }
                finally {
                    verbindung.Close();
                }
                return false;
            }
        }

        public void fehlermeldung() {
            if (tbx_name.Text == "") {
                tbx_name.Text = "Füllen sie das Feld aus";
                tbx_name.ForeColor = System.Drawing.Color.Red; // Setze die Schriftfarbe auf Rot
                bildname.Visible = true;
            }

            if (tbx_password.Text == "") {
                tbx_password.Text = "Geben Sie Ihr Passwort ein";
                tbx_password.ForeColor = System.Drawing.Color.Red; // Setze die Schriftfarbe auf Rot
                tbx_password.PasswordChar = '\0'; // Zurücksetzen auf normalen Text, da es leer ist
                bildpassword.Visible = true;
            }
        }

        private void tbx_name_Enter(object sender, EventArgs e) {
            if (tbx_name.Text == "Füllen sie das Feld aus") {
                tbx_name.Text = "";
                tbx_name.ForeColor = System.Drawing.Color.Black; // Setze die Schriftfarbe auf Schwarz

                bildname.Visible = false;
            }
        }

        private void tbx_name_Leave(object sender, EventArgs e) {
            if (tbx_name.Text == "") {
                tbx_name.Text = "Füllen sie das Feld aus";
                tbx_name.ForeColor = System.Drawing.Color.Red; // Setze die Schriftfarbe auf Rot1
                bildname.Visible = true;
            }
        }

        private void tbx_password_Enter(object sender, EventArgs e) {
            if (tbx_password.Text == "Geben Sie Ihr Passwort ein") {
                tbx_password.Text = "";
                tbx_password.ForeColor = System.Drawing.Color.Black; // Setze die Schriftfarbe auf Schwarz
                tbx_password.PasswordChar = '•';
                bildpassword.Visible = false;
            }
        }

        private void tbx_password_Leave(object sender, EventArgs e) {
            if (tbx_password.Text == "") {
                tbx_password.Text = "Geben Sie Ihr Passwort ein";
                tbx_password.ForeColor = System.Drawing.Color.Red; // Setze die Schriftfarbe auf Rot
                tbx_password.PasswordChar = '\0'; // Zurücksetzen auf normalen Text, da es leer ist
                bildpassword.Visible = true;
            }
        }

    }
}
