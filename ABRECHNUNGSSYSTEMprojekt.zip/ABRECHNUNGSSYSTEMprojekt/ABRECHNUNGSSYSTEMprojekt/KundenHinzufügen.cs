﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class KundenHinzufügen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public KundenHinzufügen() {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void KundenHinzufügen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            datagriedview();
        }
        private void datagriedview() {
            try {
                con.Open();
                ds.Clear();

                ada = new OleDbDataAdapter("select Kunden_id, Zahung_id, Kunden_vorname, Kunden_nachname, Kunden_adresse, Kunden_benutzername, Kunden_password, Rabatt_id, Punkte from Kunden", con);
                ada.Fill(ds, "kunden");


                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "kunden";

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Fehler: " + a.Message);
            }
        }
    }
}
