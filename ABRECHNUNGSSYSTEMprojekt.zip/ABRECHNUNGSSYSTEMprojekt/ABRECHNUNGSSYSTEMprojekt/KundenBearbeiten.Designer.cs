﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class KundenBearbeiten {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.dgbearbeiten = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.dgbearbeiten);
            this.panelchildform.Location = new System.Drawing.Point(-1, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1046, 452);
            this.panelchildform.TabIndex = 1;
            // 
            // dgbearbeiten
            // 
            this.dgbearbeiten.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dgbearbeiten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbearbeiten.Location = new System.Drawing.Point(0, 0);
            this.dgbearbeiten.Name = "dgbearbeiten";
            this.dgbearbeiten.RowHeadersVisible = false;
            this.dgbearbeiten.Size = new System.Drawing.Size(1046, 452);
            this.dgbearbeiten.TabIndex = 5;
            this.dgbearbeiten.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbearbeiten_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(216, 522);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(584, 73);
            this.label1.TabIndex = 6;
            this.label1.Text = "Kunden Bearbeiten";
            // 
            // KundenBearbeiten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1044, 688);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelchildform);
            this.Name = "KundenBearbeiten";
            this.Text = "KundenBearbeiten";
            this.Load += new System.EventHandler(this.KundenBearbeiten_Load);
            this.panelchildform.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgbearbeiten)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgbearbeiten;
    }
}