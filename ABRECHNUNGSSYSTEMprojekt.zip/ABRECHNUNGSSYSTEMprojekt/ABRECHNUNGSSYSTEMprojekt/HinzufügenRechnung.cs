﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;




namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class HinzufügenRechnung : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        public HinzufügenRechnung()
        {
            InitializeComponent();
        }

        private void HinzufügenRechnung_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try
            {
                //der tabelname das kein - enthalten


                cmd = new OleDbCommand("select * from Zahlungart order by Zahlung_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {

                    cbx_zahlung.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Versand order by Versand_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cbx_versand.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                cmd = new OleDbCommand("select * from Status order by Status_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cbx_status.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                cmd = new OleDbCommand("select * from Bestellung order by Bestellung_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cbx_bestellung.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Mehrwertsteuer order by Mwst_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cbx_mwst.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Konto order by Konto_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    cbx_konto.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void cbx_versand_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_versand.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Versand where Versand_id =" + vergleich, con);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    tbx_vart.Text = dr.GetString(1);
                    tbx_vkos.Text = dr.GetInt32(2).ToString();
                }

                lbl_versandkosten.Text = tbx_vkos.Text;

                BerechneGesamtkosten();
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(direkt suchen)" + a);
            }
            finally
            {
                con.Close();
            }
        }

        private void cbx_zahlung_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_zahlung.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Zahlungart where Zahlung_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_zart.Text = dr.GetString(1);
                

                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_status_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_status.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Status where Status_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_stb.Text = dr.GetString(1);


                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_mwst_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_mwst.SelectedItem.ToString());

                cmd = new OleDbCommand("select * from Mehrwertsteuer where Mwst_id =" + vergleich, con);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    tbx_mwstsatz.Text = dr.GetInt32(1).ToString();
                }

                lbl_mwst.Text = tbx_mwstsatz.Text;

                BerechneGesamtkosten();
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(direkt suchen)" + a);
            }
            finally
            {
                con.Close();
            }
        }
        private void BerechneGesamtkosten()
        {
            try
            {
                double betrag = !string.IsNullOrEmpty(tbx_betrag.Text) ? Convert.ToDouble(tbx_betrag.Text) : 0;
                double mwstSatz = !string.IsNullOrEmpty(tbx_mwstsatz.Text) ? Convert.ToDouble(tbx_mwstsatz.Text) : 0;
                double versandkosten = !string.IsNullOrEmpty(tbx_vkos.Text) ? Convert.ToDouble(tbx_vkos.Text) : 0;

                double mwstBetrag = betrag * mwstSatz / 100;
                double gesamtKosten = betrag + mwstBetrag + versandkosten;

                lbl_gesamtkosten.Text = gesamtKosten.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler bei der Berechnung der Gesamtkosten: " + ex.Message);
            }
        }

        private void tbx_betrag_TextChanged(object sender, EventArgs e)
        {
            lbl_betrag.Text = tbx_betrag.Text;
            BerechneGesamtkosten(); lbl_betrag.Text = tbx_betrag.Text;
        }

        private void tbx_mwstsatz_TextChanged(object sender, EventArgs e)
        {
            lbl_mwst.Text = tbx_mwstsatz.Text;
            BerechneGesamtkosten();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string insertCommand = "INSERT INTO Rechnung (Versand_id, Bestellung_id, Zahlung_id, Status_id, Mwst_id, Konto_id, Betrag, Lieferung, Datum) " +
                    "VALUES (@Versand_id, @Bestellung_id, @Zahlung_id, @Status_id, @Mwst_id, @Konto_id, @Betrag, @Lieferung, @Datum)";

                cmd = new OleDbCommand(insertCommand, con);
                cmd.Parameters.AddWithValue("@Versand_id", cbx_versand.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Bestellung_id", cbx_bestellung.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Zahlung_id", cbx_zahlung.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Status_id", cbx_status.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Mwst_id", cbx_mwst.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Konto_id", cbx_konto.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Betrag", tbx_betrag.Text);
                cmd.Parameters.AddWithValue("@Lieferung", tbx_lieferung.Text);
                cmd.Parameters.AddWithValue("@Datum", tbx_datum.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Datensatz erfolgreich eingefügt!");
                ExportToPDF();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Einfügen des Datensatzes: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        private void ExportToPDF()
        {
            // Erstelle ein neues Dokument
            Document doc = new Document();

            try
            {
                // Pfad zum Speichern der PDF-Datei
                string path = @"M:\Abrechnungssystemprojektneu(03.04.2024)alan.rolke.krause\ABRECHNUNGSSYSTEMprojekt\pdfs/rechnung.pdf";

                // Erstelle ein PDFWriter-Objekt zum Schreiben des Dokuments
                using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    PdfWriter.GetInstance(doc, fs);

                    // Öffne das Dokument
                    doc.Open();

                    // Füge das Logo oder die Kopfzeile hinzu (optional)
                    // ...

                    // Füge die Rechnungsinformationen hinzu
                    Paragraph header = new Paragraph("Rechnung\n\n");
                    header.Alignment = Element.ALIGN_CENTER;
                    header.Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);



                    header.Font.Size = 16;
                    doc.Add(header);

                    PdfPTable table = new PdfPTable(2);
                    table.WidthPercentage = 100;

                    AddCell(table, "Versand ID:", cbx_versand.SelectedItem.ToString());
                    AddCell(table, "Versand Art:", tbx_vart.Text);
                    AddCell(table, "Versand Kosten:", tbx_vkos.Text);
                    AddCell(table, "Bestellung ID:", cbx_bestellung.SelectedItem.ToString());
                    AddCell(table, "Zahlung ID:", cbx_zahlung.SelectedItem.ToString());
                    AddCell(table, "Zahlung Art:", tbx_zart.Text);
                    AddCell(table, "Mwst ID:", cbx_mwst.SelectedItem.ToString());
                    AddCell(table, "Mehrwertsteuer Satz:", tbx_mwstsatz.Text);
                    AddCell(table, "Konto ID:", cbx_konto.SelectedItem.ToString());
                    AddCell(table, "Status ID:", cbx_status.SelectedItem.ToString());
                    AddCell(table, "Status Bezeichnung:", tbx_stb.Text);
                    AddCell(table, "Betrag:", tbx_betrag.Text);
                    AddCell(table, "Lieferung:", tbx_lieferung.Text);
                    AddCell(table, "Datum:", tbx_datum.Text);

                    // Füge den Inhalt dem Dokument hinzu
                    doc.Add(table);

                    // Füge die Zusammenfassung hinzu
                    Paragraph summary = new Paragraph("\n\nZusammenfassung:\n");
                    summary.Alignment = Element.ALIGN_CENTER;
                    summary.Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);

                    summary.Font.Size = 14;
                    doc.Add(summary);

                    PdfPTable summaryTable = new PdfPTable(2);
                    summaryTable.WidthPercentage = 100;
                    AddCell(summaryTable, "Betrag:", lbl_betrag.Text);
                    AddCell(summaryTable, "Mehrwertsteuer:", lbl_mwst.Text);
                    AddCell(summaryTable, "Versandkosten:", lbl_versandkosten.Text);
                    AddCell(summaryTable, "Gesamtkosten:", lbl_gesamtkosten.Text);

                    // Füge die Zusammenfassung dem Dokument hinzu
                    doc.Add(summaryTable);

                    // Schließe das Dokument
                    doc.Close();
                }

                // Zeige eine Erfolgsmeldung an
                MessageBox.Show("Formular erfolgreich in PDF exportiert und gespeichert!");
            }
            catch (Exception ex)
            {
                // Bei Fehlern zeige eine Fehlermeldung an
                MessageBox.Show("Fehler beim Exportieren des Formulars in PDF: " + ex.Message);
            }
        }
        private void AddCell(PdfPTable table, string label, string value)
        {
            PdfPCell cellLabel = new PdfPCell(new Phrase(label));
            cellLabel.BorderWidth = 0;
            cellLabel.HorizontalAlignment = Element.ALIGN_LEFT;

            PdfPCell cellValue = new PdfPCell(new Phrase(value));
            cellValue.BorderWidth = 0;
            cellValue.HorizontalAlignment = Element.ALIGN_LEFT;

            table.AddCell(cellLabel);
            table.AddCell(cellValue);
        }



       
    }
}
