﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class MitarbeiterHInzufügen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panelchildform = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.panelchildform.SuspendLayout();
            this.SuspendLayout();
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.Location = new System.Drawing.Point(3, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1035, 524);
            this.dghinzufügen.TabIndex = 4;
            this.dghinzufügen.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dghinzufügen_CellContentClick);
            this.dghinzufügen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dghinzufügen_CellDoubleClick_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(163, 577);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(678, 73);
            this.label1.TabIndex = 5;
            this.label1.Text = "Mitarbeiter Hinzufügen";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panelchildform
            // 
            this.panelchildform.Controls.Add(this.dghinzufügen);
            this.panelchildform.Location = new System.Drawing.Point(-1, 1);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1038, 527);
            this.panelchildform.TabIndex = 6;
            // 
            // MitarbeiterHInzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1038, 696);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelchildform);
            this.Name = "MitarbeiterHInzufügen";
            this.Text = "MitarbeiterHInzufügen";
            this.Load += new System.EventHandler(this.MitarbeiterHInzufügen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.panelchildform.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.Panel panelchildform;
    }
}