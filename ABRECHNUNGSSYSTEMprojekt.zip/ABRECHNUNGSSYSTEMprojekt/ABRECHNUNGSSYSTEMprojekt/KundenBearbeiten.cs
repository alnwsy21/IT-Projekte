﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class KundenBearbeiten : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public KundenBearbeiten() {
            InitializeComponent();
            CustomizeDataGridView();
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void KundenBearbeiten_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            LoadData();
            AdjustDataGridViewSize();
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dgbearbeiten.AllowUserToAddRows = false;
            dgbearbeiten.AllowUserToDeleteRows = false;
            dgbearbeiten.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgbearbeiten.RowHeadersVisible = false;
            dgbearbeiten.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgbearbeiten.MultiSelect = false;
            dgbearbeiten.ReadOnly = true;
            dgbearbeiten.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dgbearbeiten.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.DefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dgbearbeiten.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dgbearbeiten.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dgbearbeiten.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dgbearbeiten.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dgbearbeiten.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dgbearbeiten.Size = new Size(panelchildform.Width - 20, panelchildform.Height - 20);
            dgbearbeiten.Location = new Point(10, 10);
        }
        private void LoadData() {
            try {
                ds.Clear();

                using (OleDbDataAdapter ada = new OleDbDataAdapter("select Kunden_id, Zahlung_id, Kunden_vorname, Kunden_nachname, Kunden_adresse, Kunden_benutzername, Kunden_password, Rabatt_id, Punkte from Kunde", con)) {
                    ada.Fill(ds, "Kunden");
                }

                dgbearbeiten.DataSource = ds;
                dgbearbeiten.DataMember = "kunden";


            }
            catch (Exception a) {
                MessageBox.Show("Fehler bei: " + a.Message);
            }
            finally {
                con.Close();
            }

        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];
                BearbeitenKunden bearbeiten = new BearbeitenKunden(selectedRow, connectionString);
                openchildform(bearbeiten);
            }
        }
    }
}
