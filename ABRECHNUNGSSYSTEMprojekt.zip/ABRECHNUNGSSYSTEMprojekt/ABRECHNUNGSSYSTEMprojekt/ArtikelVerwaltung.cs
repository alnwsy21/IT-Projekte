﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class ArtikelVerwaltung : Form {
        public ArtikelVerwaltung() {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void button1_Click(object sender, EventArgs e) {
            openchildform(new ArtikelAnzeigen());
        }

        private void ArtikelVerwaltung_Load(object sender, EventArgs e) {

        }

        private void panelchildform_Paint(object sender, PaintEventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            openchildform(new ArtikelHinzufügen());
        }

        private void button3_Click(object sender, EventArgs e) {
            openchildform(new ArtikelBearbeiten());
        }

        private void button4_Click(object sender, EventArgs e) {
            openchildform(new ArtikelEntfernen());
        }
    }
}
