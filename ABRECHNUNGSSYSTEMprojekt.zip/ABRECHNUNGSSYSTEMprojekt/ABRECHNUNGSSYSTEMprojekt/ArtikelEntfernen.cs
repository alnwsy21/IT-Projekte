﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class ArtikelEntfernen : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public ArtikelEntfernen() {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void ArtikelEntfernen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb";
                con.Open();

                // Initialisiere ada hier
                ada = new OleDbDataAdapter();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            datagriedview();
            AdjustDataGridViewSize();
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dgentfernen.AllowUserToAddRows = false;
            dgentfernen.AllowUserToDeleteRows = false;
            dgentfernen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgentfernen.RowHeadersVisible = false;
            dgentfernen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgentfernen.MultiSelect = false;
            dgentfernen.ReadOnly = true;
            dgentfernen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgentfernen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dgentfernen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgentfernen.DefaultCellStyle.ForeColor = Color.White;
            dgentfernen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dgentfernen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgentfernen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgentfernen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dgentfernen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dgentfernen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dgentfernen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dgentfernen.ScrollBars = ScrollBars.Both;
        }
        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dgentfernen.Size = new Size(panelchildform.Width - 20, panelchildform.Height - 20);
            dgentfernen.Location = new Point(10, 10);
        }
        private void datagriedview() {
            try {
                ds.Clear();

                // Verwende die globale Variable ada
                ada.SelectCommand = new OleDbCommand("select Artikel_id, Gruppen_id, Artikel_bezeichnung, Menge, Artikel_preis, Kassen_id from Artikel WHERE Artikel_gelöscht = false", con);
                ada.Fill(ds, "Artikel");

                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Artikel";


            }
            catch (Exception a) {
                MessageBox.Show("Fehler bei: " + a.Message);
            }
            finally {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (clicked == true) {
                con.Open();
                cmd = new OleDbCommand("Update Artikel set Artikel_gelöscht = true where Artikel_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Artikel");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Artikel";
                con.Close();
            }
            else {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Artikel_id Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            openchildform(new EntfernenArtikel());
            ds.Clear();
            ada.Fill(ds, "Artikel");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Artikel";
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
            }
        }
    }
}
