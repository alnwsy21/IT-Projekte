﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class MitarbeiterBearbeiten : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public MitarbeiterBearbeiten() {
            InitializeComponent();
            CustomizeDataGridView();
        }
        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void MitarbeiterBearbeiten_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            LoadData();
            AdjustDataGridViewSize();
        }
        private void LoadData() {
            try {
                ds.Clear();

                using (OleDbDataAdapter ada = new OleDbDataAdapter("SELECT Mitarbeiter_id, Vorname, Nachname, Pos, Benutzername, Passwort, Rechte FROM Mitarbeiter", con)) {
                    ada.Fill(ds, "Mitarbeiter");
                }

                dgbearbeiten.DataSource = ds;
                dgbearbeiten.DataMember = "Mitarbeiter";

                
            }
            catch (Exception a) {
                MessageBox.Show("Fehler bei: " + a.Message);
            }
            finally {
                con.Close();
            }

        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dgbearbeiten.AllowUserToAddRows = false;
            dgbearbeiten.AllowUserToDeleteRows = false;
            dgbearbeiten.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgbearbeiten.RowHeadersVisible = false;
            dgbearbeiten.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgbearbeiten.MultiSelect = false;
            dgbearbeiten.ReadOnly = true;
            dgbearbeiten.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dgbearbeiten.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.DefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dgbearbeiten.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dgbearbeiten.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dgbearbeiten.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dgbearbeiten.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dgbearbeiten.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dgbearbeiten.Size = new Size(panelchildform.Width - 20, panelchildform.Height - 20);
            dgbearbeiten.Location = new Point(10, 10);
        }
        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];
                BearbeitenMitarbeiter bearbeiten = new BearbeitenMitarbeiter(selectedRow, connectionString);
                openchildform(bearbeiten);
            }
        }
    }
}
