﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class MitarbeiterAnzeigen : Form {
        OleDbCommand cmd = new OleDbCommand();
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public MitarbeiterAnzeigen() {
            InitializeComponent();

            CustomizeDataGridView();
        }

        private void MitarbeiterAnzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
              con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            datagriedview();
            AdjustDataGridViewSize();
        }
        private void datagriedview() {
            try {
                con.Open();
                ds.Clear();

                ada = new OleDbDataAdapter("SELECT Mitarbeiter_id, Vorname, Nachname, Pos, Benutzername, Passwort, Rechte FROM Mitarbeiter", con);
                ada.Fill(ds, "Mitarbeiter");

                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Mitarbeiter";
            }
            catch (Exception a) {
                MessageBox.Show("Fehler beim Laden der Daten: " + a.Message);
            }
            finally {
                if (con.State == ConnectionState.Open) {
                    con.Close();
                }
            }

      
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dganzeigen.AllowUserToAddRows = false;
            dganzeigen.AllowUserToDeleteRows = false;
            dganzeigen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dganzeigen.RowHeadersVisible = false;
            dganzeigen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dganzeigen.MultiSelect = false;
            dganzeigen.ReadOnly = true;
            dganzeigen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dganzeigen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dganzeigen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dganzeigen.DefaultCellStyle.ForeColor = Color.White;
            dganzeigen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dganzeigen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dganzeigen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dganzeigen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dganzeigen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dganzeigen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dganzeigen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dganzeigen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dganzeigen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dganzeigen.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dganzeigen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dganzeigen.Location = new Point(10, 10);
        }
        private void label1_Click(object sender, EventArgs e) {

        }
    }
}
