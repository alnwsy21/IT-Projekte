﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class BearbeitenMitarbeiter : Form {
        OleDbCommand cmd = null;

        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }
        public BearbeitenMitarbeiter(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenMitarbeiter_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }
        private void AnzeigenDerDaten() {
            try {
                // Beachte, dass ich `SelectedItem` durch `Text` ersetzt habe, da du jetzt eine TextBox verwendest
                tbx_vorname.Text = selectedRow.Cells["Vorname"].Value.ToString();
                tbx_nachname.Text = selectedRow.Cells["Nachname"].Value.ToString();
                tbx_position.Text = selectedRow.Cells["Pos"].Value.ToString();
                tbx_benutzername.Text = selectedRow.Cells["Benutzername"].Value.ToString();
                tbx_password.Text = selectedRow.Cells["Passwort"].Value.ToString();
                cbx_rechte.Text = selectedRow.Cells["Rechte"].Value.ToString();
                
                

                // Füge hier die Logik für die Anzeige der Daten in den anderen beiden TextBoxen hinzu.
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try {
                using (OleDbConnection con = new OleDbConnection(connectionString)) {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_vorname.Text) || string.IsNullOrWhiteSpace(tbx_nachname.Text)
                        || string.IsNullOrWhiteSpace(tbx_position.Text) || string.IsNullOrWhiteSpace(tbx_benutzername.Text) || string.IsNullOrWhiteSpace(tbx_password.Text)
                        || string.IsNullOrWhiteSpace(cbx_rechte.Text)) {

                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else {
                        string query = "UPDATE Mitarbeiter SET Vorname = ?, Nachname = ?, Pos = ?, Benutzername = ?, Passwort = ? , Rechte = ? WHERE Mitarbeiter_id = ?";
                        using (OleDbCommand insertCmd = new OleDbCommand(query, con)) {
                            insertCmd.Parameters.AddWithValue("@Vorname", tbx_vorname.Text);
                            insertCmd.Parameters.AddWithValue("@Nachname", tbx_nachname.Text);
                            insertCmd.Parameters.AddWithValue("@Pos", tbx_position.Text);
                            insertCmd.Parameters.AddWithValue("@Benutzername", tbx_benutzername.Text);
                            // Hier das Passwort sicher verschlüsseln
                            insertCmd.Parameters.AddWithValue("@Passwort", tbx_password.Text);
                            insertCmd.Parameters.AddWithValue("@Rechte", cbx_rechte.Text);
                            insertCmd.Parameters.AddWithValue("@Mitarbeiter_id", selectedRow.Cells["Mitarbeiter_id"].Value);

                            insertCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        UpdatedRow = selectedRow;
                    }
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Bearbeiten der Daten: " + ex.Message);
            }

        }
    }
}
