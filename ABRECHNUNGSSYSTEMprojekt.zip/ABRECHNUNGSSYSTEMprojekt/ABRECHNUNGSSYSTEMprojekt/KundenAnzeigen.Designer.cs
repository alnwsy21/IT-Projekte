﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class KundenAnzeigen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.dganzeigen = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dganzeigen)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(223, 521);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(541, 73);
            this.label1.TabIndex = 3;
            this.label1.Text = "Kunden Anzeigen";
            // 
            // dganzeigen
            // 
            this.dganzeigen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.dganzeigen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dganzeigen.Location = new System.Drawing.Point(-3, 0);
            this.dganzeigen.Name = "dganzeigen";
            this.dganzeigen.RowHeadersVisible = false;
            this.dganzeigen.Size = new System.Drawing.Size(1046, 425);
            this.dganzeigen.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dganzeigen);
            this.panel1.Location = new System.Drawing.Point(1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1046, 425);
            this.panel1.TabIndex = 5;
            // 
            // KundenAnzeigen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1044, 688);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "KundenAnzeigen";
            this.Text = "KundenAnzeigen";
            this.Load += new System.EventHandler(this.KundenAnzeigen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dganzeigen)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dganzeigen;
        private System.Windows.Forms.Panel panel1;
    }
}