﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class ArtikelHinzufügen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.dghinzufügen);
            this.panelchildform.Location = new System.Drawing.Point(-2, -1);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1046, 464);
            this.panelchildform.TabIndex = 1;
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.Location = new System.Drawing.Point(0, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersVisible = false;
            this.dghinzufügen.Size = new System.Drawing.Size(1046, 464);
            this.dghinzufügen.TabIndex = 5;
            this.dghinzufügen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dghinzufügen_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(238, 537);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(553, 73);
            this.label1.TabIndex = 7;
            this.label1.Text = "Artikel Hinzufügen";
            // 
            // ArtikelHinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1043, 696);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelchildform);
            this.Name = "ArtikelHinzufügen";
            this.Text = "ArtikelHinzufügen";
            this.Load += new System.EventHandler(this.ArtikelHinzufügen_Load);
            this.panelchildform.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.DataGridView dghinzufügen;
        private System.Windows.Forms.Label label1;
    }
}