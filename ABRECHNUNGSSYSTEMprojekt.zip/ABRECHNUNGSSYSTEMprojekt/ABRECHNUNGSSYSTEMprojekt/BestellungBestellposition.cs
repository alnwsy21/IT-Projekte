﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class BestellungBestellposition : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        public BestellungBestellposition()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void CalculateTotalCost()
        {
            try
            {
                // Überprüfe, ob Menge und Preis gültige Zahlen sind
                if (double.TryParse(tbx_menge.Text, out double menge) && double.TryParse(tbx_preis.Text, out double preis))
                {
                    double gesamtkosten = menge * preis;

                    // Überprüfe, ob Rabatt ausgewählt wurde
                    if (!string.IsNullOrEmpty(tbx_rabattsatz.Text))
                    {
                        // Überprüfe, ob Rabattsatz eine gültige Zahl ist
                        if (double.TryParse(tbx_rabattsatz.Text, out double rabattsatz))
                        {
                            // Berechne Gesamtkosten mit Rabatt
                            gesamtkosten = gesamtkosten - (gesamtkosten * (rabattsatz / 100));
                        }
                    }

                    // Aktualisiere den Wert in tbx_gesamtkosten
                    tbx_gesamtkosten.Text = gesamtkosten.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Berechnen der Gesamtkosten: " + ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BestellungBestellposition_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Datenbank-öffnungsfehler: " + ex.Message);
            }
            FillComboBoxes();
            PopulateDataGridView();
            AdjustDataGridViewSize();
        }
        private void PopulateDataGridView()
        {
            try
            {
                con.Open();
                ds.Clear();

                // Ändere die Reihenfolge der Abfrage, um die neuesten Einträge zuerst zu erhalten
                ada = new OleDbDataAdapter("SELECT Bestellung_id, artikel_id, rabatt_id, menge, preis FROM Bestellposition ORDER BY bestellposition_id ASC", con);
                ada.Fill(ds, "Bestellposition");

                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Bestellposition";

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void FillComboBoxFromQuery(string query, ComboBox comboBox)
        {
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            dr.Close();
        }
        private void FillComboBoxes()
        {
            try
            {
                con.Open();

                FillComboBoxFromQuery("SELECT Rabatt_id FROM Rabatt ORDER BY Rabatt_id ASC", cbx_rabatt);
                FillComboBoxFromQuery("SELECT Artikel_id FROM Artikel ORDER BY Artikel_id ASC", cbx_artikel);
                FillComboBoxFromQuery("SELECT Bestellung_id FROM Bestellung ORDER BY Bestellung_id ASC", cbx_bestellung);

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Zugriff auf die Tabellen: " + ex.Message);
            }
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dghinzufügen.AllowUserToAddRows = false;
            dghinzufügen.AllowUserToDeleteRows = false;
            dghinzufügen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dghinzufügen.RowHeadersVisible = false;
            dghinzufügen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dghinzufügen.MultiSelect = false;
            dghinzufügen.ReadOnly = true;
            dghinzufügen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dghinzufügen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.DefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dghinzufügen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dghinzufügen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dghinzufügen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dghinzufügen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dghinzufügen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dghinzufügen.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dghinzufügen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dghinzufügen.Location = new Point(10, 10);
        }

        private void cbx_artikel_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            

        }

        private void cbx_rabatt_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void tbx_menge_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void tbx_rabattsatz_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openchildform(new Bestellungaufgeben());
        }

        private void cbx_artikel_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_artikel.SelectedItem.ToString());

                // Es wird ein neuer Zugriff (direktzugriff) auf die Datenbank ausgeführt
                cmd = new OleDbCommand("select * from Artikel where Artikel_id =" + vergleich, con);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    tbx_artikel.Text = dr.GetString(2);
                    // tbx_menge.Text = dr.GetInt32(3).ToString();
                    tbx_preis.Text = dr.GetInt32(4).ToString();

                    // Berechne Gesamtkosten, wenn Menge vorhanden ist
                    if (!string.IsNullOrEmpty(tbx_menge.Text))
                    {
                        CalculateTotalCost();
                    }
                }
                else
                {
                    MessageBox.Show("Artikel nicht gefunden.");
                }

                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (direkt suchen): " + a);
            }
        }

        private void cbx_rabatt_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_rabatt.SelectedItem.ToString());

                // Es wird ein neuer Zugriff (direktzugriff) auf die Datenbank ausgeführt
                cmd = new OleDbCommand("select * from Rabatt where Rabatt_id =" + vergleich, con);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    tbx_rabattsatz.Text = dr.GetInt32(4).ToString();

                    // Berechne Gesamtkosten, wenn Menge vorhanden ist
                    if (!string.IsNullOrEmpty(tbx_menge.Text))
                    {
                        CalculateTotalCost();
                    }
                }
                else
                {
                    MessageBox.Show("Rabatt nicht gefunden.");
                }

                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (direkt suchen): " + a);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbx_menge_TextChanged_1(object sender, EventArgs e)
        {
            CalculateTotalCost();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(cbx_bestellung.Text) || string.IsNullOrWhiteSpace(cbx_artikel.Text)
                        || string.IsNullOrWhiteSpace(tbx_menge.Text) || string.IsNullOrWhiteSpace(tbx_preis.Text))
                    {
                        MessageBox.Show("Bitte füllen Sie alle erforderlichen Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Bestellposition (Bestellung_id, Artikel_id, Rabatt_id, menge, preis) " +
                            "VALUES (@best, @art, @rab, @menge, @preis)", con))
                        {
                            insertCmd.Parameters.AddWithValue("@best", Convert.ToInt32(cbx_bestellung.Text));
                            insertCmd.Parameters.AddWithValue("@art", Convert.ToInt32(cbx_artikel.Text));

                            // Füge den Rabatt nur hinzu, wenn ein Rabatt ausgewählt wurde
                            if (!string.IsNullOrWhiteSpace(cbx_rabatt.Text))
                            {
                                insertCmd.Parameters.AddWithValue("@rab", Convert.ToInt32(cbx_rabatt.Text));
                            }
                            else
                            {
                                // Füge NULL ein, um anzugeben, dass kein Rabatt vorhanden ist
                                insertCmd.Parameters.AddWithValue("@rab", DBNull.Value);
                            }

                            insertCmd.Parameters.AddWithValue("@menge", Convert.ToInt32(tbx_menge.Text));
                            insertCmd.Parameters.AddWithValue("@preis", Convert.ToInt32(tbx_preis.Text));

                            insertCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        // Nach dem Einfügen der Bestellung die DataGridView aktualisieren
                        PopulateDataGridView();
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message);
            }
        }
    }
}
