﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class BestellungBearbeiten : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        public BestellungBearbeiten()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void BestellungBearbeiten_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            LoadData();
            AdjustDataGridViewSize();
        }
        private void LoadData()
        {
            try
            {
                ds.Clear();

                using (OleDbDataAdapter ada = new OleDbDataAdapter("SELECT * from Bestellposition ", con))
                {
                    ada.Fill(ds, "Bestellung");
                }

                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "Bestellung";


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler bei: " + a.Message);
            }
            finally
            {
                con.Close();
            }

        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dghinzufügen.AllowUserToAddRows = false;
            dghinzufügen.AllowUserToDeleteRows = false;
            dghinzufügen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dghinzufügen.RowHeadersVisible = false;
            dghinzufügen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dghinzufügen.MultiSelect = false;
            dghinzufügen.ReadOnly = true;
            dghinzufügen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dghinzufügen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.DefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dghinzufügen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dghinzufügen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dghinzufügen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dghinzufügen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dghinzufügen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dghinzufügen.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dghinzufügen.Size = new Size(panelchildform.Width - 20, panelchildform.Height - 20);
            dghinzufügen.Location = new Point(10, 10);
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 )
            {
                // Extrahiere die Daten aus der ausgewählten Zeile
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];
                string bestellung = selectedRow.Cells["Bestellung_id"].Value.ToString(); // Ersetze "Name_der_Bestellungsspalte" durch den tatsächlichen Namen der Spalte für die Bestellung
                string artikel = selectedRow.Cells["Artikel_id"].Value.ToString(); // Ersetze "Name_der_ArtikelSpalte" durch den tatsächlichen Namen der Spalte für den Artikel
                string rabatt = selectedRow.Cells["Rabatt_id"].Value.ToString(); // Ersetze "Name_der_RabattSpalte" durch den tatsächlichen Namen der Spalte für den Rabatt
                string preis = selectedRow.Cells["Preis"].Value.ToString(); // Ersetze "Name_der_PreisSpalte" durch den tatsächlichen Namen der Spalte für den Preis
                string menge = selectedRow.Cells["menge"].Value.ToString(); // Ersetze "Name_der_MengeSpalte" durch den tatsächlichen Namen der Spalte für die Menge

                // Setze die Werte in die entsprechenden TextBoxen und ComboBoxen
                cbx_bestellung.Text = bestellung;
                cbx_artikel.Text = artikel;
                cbx_rabatt.Text = rabatt;
                tbx_preis.Text = preis;
                tbx_menge.Text = menge;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_menge.Text) || string.IsNullOrWhiteSpace(tbx_preis.Text))
                    {
                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        // Erhalte die Bestellpositions-ID aus der ausgewählten Zeile der DataGridView
                        int bestellpositionId = Convert.ToInt32(dghinzufügen.SelectedRows[0].Cells["bestellposition_id"].Value);

                        string query = "UPDATE Bestellposition SET Bestellung_id = ?, Artikel_id = ?, Rabatt_id = ?, Menge = ?, preis = ? " +
                                       "WHERE bestellposition_id = ?";
                        using (OleDbCommand updateCmd = new OleDbCommand(query, con))
                        {
                            updateCmd.Parameters.AddWithValue("@best", Convert.ToInt32(cbx_bestellung.Text));
                            updateCmd.Parameters.AddWithValue("@art", Convert.ToInt32(cbx_artikel.Text));
                            updateCmd.Parameters.AddWithValue("@rab", Convert.ToInt32(cbx_rabatt.Text));
                            updateCmd.Parameters.AddWithValue("@menge", Convert.ToInt32(tbx_menge.Text));
                            updateCmd.Parameters.AddWithValue("@preis", Convert.ToInt32(tbx_preis.Text));
                            updateCmd.Parameters.AddWithValue("@bestellpositionId", bestellpositionId);

                            updateCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        // Nachdem die Daten erfolgreich bearbeitet wurden, lade die Daten erneut in die DataGridView
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Bearbeiten der Daten: " + ex.Message);
            }



        }
    }
}
