﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class EntfernenArtikel : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        bool clicked;
        string mnr = "";
        public EntfernenArtikel() {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void EntfernenArtikel_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source= Tech.accdb";
                con.Open();
                con.Close();
            }
            catch {
                MessageBox.Show("Die Datenbank konnte nicht geöffnet werden");
            }

            try {
                con.Open();
                ada = new OleDbDataAdapter("select * from Artikel where Artikel_gelöscht = true", con);
                ada.Fill(ds, "Artikel");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Artikel";

                con.Close();

            }
            catch {
                MessageBox.Show("Der Datensatz konnte nicht gelöscht werden");
            }
            AdjustDataGridViewSize();
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dgentfernen.AllowUserToAddRows = false;
            dgentfernen.AllowUserToDeleteRows = false;
            dgentfernen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgentfernen.RowHeadersVisible = false;
            dgentfernen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgentfernen.MultiSelect = false;
            dgentfernen.ReadOnly = true;
            dgentfernen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgentfernen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dgentfernen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgentfernen.DefaultCellStyle.ForeColor = Color.White;
            dgentfernen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dgentfernen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgentfernen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgentfernen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dgentfernen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgentfernen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dgentfernen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dgentfernen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dgentfernen.ScrollBars = ScrollBars.Both;
        }
        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dgentfernen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dgentfernen.Location = new Point(10, 10);
        }
        private void button2_Click(object sender, EventArgs e) {
            try {
                if (dgentfernen.SelectedRows.Count > 0) {
                    con.Open();
                    cmd = new OleDbCommand("Update Artikel set Artikel_gelöscht = false where Artikel_id = " + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "Artikel");
                    dgentfernen.DataSource = ds;
                    dgentfernen.DataMember = "Artikel";
                    con.Close();
                }
                else {
                    MessageBox.Show("Bitte wählen Sie einen Datensatz aus, um ihn zu aktualisieren.");
                }
            }
            catch (Exception a) {
                MessageBox.Show("Der Datensatz konnte nicht hinzugefügt werden" + a);
            }
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["Artikel_id"].FormattedValue.ToString();
            }
        }


    }
}
