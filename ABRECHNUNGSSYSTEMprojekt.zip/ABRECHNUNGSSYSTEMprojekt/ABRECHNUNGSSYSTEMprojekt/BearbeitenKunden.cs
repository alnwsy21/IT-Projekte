﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class BearbeitenKunden : Form {
        OleDbCommand cmd = null;

        OleDbDataReader dr = null;
        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }
        public BearbeitenKunden(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void BearbeitenKunden_Load(object sender, EventArgs e) {


            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";
                AnzeigenDerDaten();
                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten


                cmd = new OleDbCommand("select * from ZahlungArt order by Zahlung_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {

                    cbx_zahl.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                cmd = new OleDbCommand("select * from Rabatt order by Rabatt_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                while (dr.Read()) {

                    cbx_rabatt.Items.Add(dr.GetInt32(0));

                    //   cbx_kid.Items.Add(dr.GetInt32(0));
                }

                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
            
        }
        private void AnzeigenDerDaten() {
            try {
                // Beachte, dass ich `SelectedItem` durch `Text` ersetzt habe, da du jetzt eine TextBox verwendest
                cbx_zahl.Text = selectedRow.Cells["Zahlung_id"].Value.ToString();
                tbx_vorname.Text = selectedRow.Cells["Kunden_vorname"].Value.ToString();
                tbx_nachname.Text = selectedRow.Cells["Kunden_nachname"].Value.ToString();
                tbx_adresse.Text = selectedRow.Cells["Kunden_adresse"].Value.ToString();
                tbx_benutzername.Text = selectedRow.Cells["Kunden_benutzername"].Value.ToString();
                tbx_password.Text = selectedRow.Cells["Kunden_password"].Value.ToString();
                cbx_rabatt.Text = selectedRow.Cells["Rabatt_id"].Value.ToString();
                tbx_punkte.Text = selectedRow.Cells["Punkte"].Value.ToString();



                // Füge hier die Logik für die Anzeige der Daten in den anderen beiden TextBoxen hinzu.
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try {
                using (OleDbConnection con = new OleDbConnection(connectionString)) {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_vorname.Text) || string.IsNullOrWhiteSpace(tbx_nachname.Text)
                         || string.IsNullOrWhiteSpace(tbx_punkte.Text) || string.IsNullOrWhiteSpace(tbx_benutzername.Text) || string.IsNullOrWhiteSpace(tbx_password.Text)
                         || string.IsNullOrWhiteSpace(cbx_zahl.Text) || string.IsNullOrWhiteSpace(cbx_rabatt.Text)) {

                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else {
                        string query = "UPDATE Kunde SET Zahlung_id = ?, Kunden_vorname = ?, Kunden_nachname = ?, Kunden_adresse = ?, Kunden_benutzername = ?, Kunden_password = ?, Rabatt_id = ?, Punkte = ? WHERE Kunden_id = ?";
                        using (OleDbCommand insertCmd = new OleDbCommand(query, con)) {
                            insertCmd.Parameters.AddWithValue("@Zahlung_id", Convert.ToInt32(cbx_zahl.Text));
                            insertCmd.Parameters.AddWithValue("@Kunden_vorname", tbx_vorname.Text);
                            insertCmd.Parameters.AddWithValue("@Kunden_nachname", tbx_nachname.Text);
                            insertCmd.Parameters.AddWithValue("@Kunden_adresse", tbx_adresse.Text);
                            insertCmd.Parameters.AddWithValue("@Kunden_benutzername", tbx_benutzername.Text);
                            // Hier das Passwort sicher verschlüsseln
                            insertCmd.Parameters.AddWithValue("@Kunden_password", tbx_password.Text);
                            insertCmd.Parameters.AddWithValue("@Rabatt_id", Convert.ToInt32(cbx_rabatt.Text));
                            insertCmd.Parameters.AddWithValue("@Punkte", Convert.ToInt32(tbx_punkte.Text));
                            insertCmd.Parameters.AddWithValue("@Kunden_id", selectedRow.Cells["Kunden_id"].Value);

                            insertCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        UpdatedRow = selectedRow;
                    }
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt    
                MessageBox.Show("Fehler beim Bearbeiten der Daten: " + ex.Message);
            }


        }
    }
}
