﻿
namespace ABRECHNUNGSSYSTEMprojekt
{
    partial class HinzufügenRechnung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_vart = new System.Windows.Forms.TextBox();
            this.cbx_versand = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_vkos = new System.Windows.Forms.TextBox();
            this.cbx_bestellung = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbx_zart = new System.Windows.Forms.TextBox();
            this.cbx_zahlung = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_stb = new System.Windows.Forms.TextBox();
            this.cbx_status = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbx_mwstsatz = new System.Windows.Forms.TextBox();
            this.cbx_mwst = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbx_konto = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbx_betrag = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbx_lieferung = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbx_datum = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_gesamtkosten = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_mwst = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbl_betrag = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_versandkosten = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(44, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 25);
            this.label6.TabIndex = 35;
            this.label6.Text = "Versand Art:";
            // 
            // tbx_vart
            // 
            this.tbx_vart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_vart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_vart.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_vart.Location = new System.Drawing.Point(261, 52);
            this.tbx_vart.Multiline = true;
            this.tbx_vart.Name = "tbx_vart";
            this.tbx_vart.Size = new System.Drawing.Size(173, 27);
            this.tbx_vart.TabIndex = 34;
            // 
            // cbx_versand
            // 
            this.cbx_versand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_versand.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_versand.FormattingEnabled = true;
            this.cbx_versand.Location = new System.Drawing.Point(261, 29);
            this.cbx_versand.Name = "cbx_versand";
            this.cbx_versand.Size = new System.Drawing.Size(173, 21);
            this.cbx_versand.TabIndex = 33;
            this.cbx_versand.SelectedIndexChanged += new System.EventHandler(this.cbx_versand_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(21, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 32;
            this.label1.Text = "Versand ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(44, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 25);
            this.label2.TabIndex = 37;
            this.label2.Text = "Versand Kosten";
            // 
            // tbx_vkos
            // 
            this.tbx_vkos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_vkos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_vkos.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_vkos.Location = new System.Drawing.Point(261, 77);
            this.tbx_vkos.Multiline = true;
            this.tbx_vkos.Name = "tbx_vkos";
            this.tbx_vkos.Size = new System.Drawing.Size(173, 27);
            this.tbx_vkos.TabIndex = 36;
            // 
            // cbx_bestellung
            // 
            this.cbx_bestellung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_bestellung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_bestellung.FormattingEnabled = true;
            this.cbx_bestellung.Location = new System.Drawing.Point(837, 23);
            this.cbx_bestellung.Name = "cbx_bestellung";
            this.cbx_bestellung.Size = new System.Drawing.Size(173, 21);
            this.cbx_bestellung.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(620, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 25);
            this.label3.TabIndex = 38;
            this.label3.Text = "Bestellung ID:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(44, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 25);
            this.label5.TabIndex = 43;
            this.label5.Text = "Zahlung Art:";
            // 
            // tbx_zart
            // 
            this.tbx_zart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_zart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_zart.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_zart.Location = new System.Drawing.Point(261, 154);
            this.tbx_zart.Multiline = true;
            this.tbx_zart.Name = "tbx_zart";
            this.tbx_zart.Size = new System.Drawing.Size(173, 27);
            this.tbx_zart.TabIndex = 42;
            // 
            // cbx_zahlung
            // 
            this.cbx_zahlung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_zahlung.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_zahlung.FormattingEnabled = true;
            this.cbx_zahlung.Location = new System.Drawing.Point(261, 131);
            this.cbx_zahlung.Name = "cbx_zahlung";
            this.cbx_zahlung.Size = new System.Drawing.Size(173, 21);
            this.cbx_zahlung.TabIndex = 41;
            this.cbx_zahlung.SelectedIndexChanged += new System.EventHandler(this.cbx_zahlung_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(21, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 25);
            this.label7.TabIndex = 40;
            this.label7.Text = "Zahlung ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(44, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(198, 25);
            this.label4.TabIndex = 47;
            this.label4.Text = "Status  Bezeichnung:";
            // 
            // tbx_stb
            // 
            this.tbx_stb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_stb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_stb.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_stb.Location = new System.Drawing.Point(261, 229);
            this.tbx_stb.Multiline = true;
            this.tbx_stb.Name = "tbx_stb";
            this.tbx_stb.Size = new System.Drawing.Size(173, 27);
            this.tbx_stb.TabIndex = 46;
            // 
            // cbx_status
            // 
            this.cbx_status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_status.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_status.FormattingEnabled = true;
            this.cbx_status.Location = new System.Drawing.Point(261, 206);
            this.cbx_status.Name = "cbx_status";
            this.cbx_status.Size = new System.Drawing.Size(173, 21);
            this.cbx_status.TabIndex = 45;
            this.cbx_status.SelectedIndexChanged += new System.EventHandler(this.cbx_status_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(21, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 25);
            this.label8.TabIndex = 44;
            this.label8.Text = "Status ID:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gainsboro;
            this.label9.Location = new System.Drawing.Point(44, 313);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(189, 25);
            this.label9.TabIndex = 51;
            this.label9.Text = "Mehrwertsteuersatz:";
            // 
            // tbx_mwstsatz
            // 
            this.tbx_mwstsatz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_mwstsatz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_mwstsatz.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_mwstsatz.Location = new System.Drawing.Point(261, 313);
            this.tbx_mwstsatz.Multiline = true;
            this.tbx_mwstsatz.Name = "tbx_mwstsatz";
            this.tbx_mwstsatz.Size = new System.Drawing.Size(173, 27);
            this.tbx_mwstsatz.TabIndex = 50;
            this.tbx_mwstsatz.TextChanged += new System.EventHandler(this.tbx_mwstsatz_TextChanged);
            // 
            // cbx_mwst
            // 
            this.cbx_mwst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_mwst.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_mwst.FormattingEnabled = true;
            this.cbx_mwst.Location = new System.Drawing.Point(261, 290);
            this.cbx_mwst.Name = "cbx_mwst";
            this.cbx_mwst.Size = new System.Drawing.Size(173, 21);
            this.cbx_mwst.TabIndex = 49;
            this.cbx_mwst.SelectedIndexChanged += new System.EventHandler(this.cbx_mwst_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(21, 290);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(177, 25);
            this.label10.TabIndex = 48;
            this.label10.Text = "Mehrwertsteuer ID:";
            // 
            // cbx_konto
            // 
            this.cbx_konto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_konto.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_konto.FormattingEnabled = true;
            this.cbx_konto.Location = new System.Drawing.Point(837, 66);
            this.cbx_konto.Name = "cbx_konto";
            this.cbx_konto.Size = new System.Drawing.Size(173, 21);
            this.cbx_konto.TabIndex = 53;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(620, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 25);
            this.label11.TabIndex = 52;
            this.label11.Text = "Konto ID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gainsboro;
            this.label12.Location = new System.Drawing.Point(620, 125);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 25);
            this.label12.TabIndex = 55;
            this.label12.Text = "Betrag:";
            // 
            // tbx_betrag
            // 
            this.tbx_betrag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_betrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_betrag.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_betrag.Location = new System.Drawing.Point(837, 125);
            this.tbx_betrag.Multiline = true;
            this.tbx_betrag.Name = "tbx_betrag";
            this.tbx_betrag.Size = new System.Drawing.Size(173, 27);
            this.tbx_betrag.TabIndex = 54;
            this.tbx_betrag.TextChanged += new System.EventHandler(this.tbx_betrag_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(620, 177);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 25);
            this.label13.TabIndex = 57;
            this.label13.Text = "Lieferung:";
            // 
            // tbx_lieferung
            // 
            this.tbx_lieferung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_lieferung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_lieferung.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_lieferung.Location = new System.Drawing.Point(837, 177);
            this.tbx_lieferung.Multiline = true;
            this.tbx_lieferung.Name = "tbx_lieferung";
            this.tbx_lieferung.Size = new System.Drawing.Size(173, 27);
            this.tbx_lieferung.TabIndex = 56;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(620, 232);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 25);
            this.label14.TabIndex = 59;
            this.label14.Text = "Datum:";
            // 
            // tbx_datum
            // 
            this.tbx_datum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_datum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_datum.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_datum.Location = new System.Drawing.Point(837, 232);
            this.tbx_datum.Multiline = true;
            this.tbx_datum.Name = "tbx_datum";
            this.tbx_datum.Size = new System.Drawing.Size(173, 27);
            this.tbx_datum.TabIndex = 58;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gainsboro;
            this.label15.Location = new System.Drawing.Point(-4, 342);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(1057, 25);
            this.label15.TabIndex = 60;
            this.label15.Text = "_________________________________________________________________________________" +
    "______________";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gainsboro;
            this.label16.Location = new System.Drawing.Point(620, 654);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 25);
            this.label16.TabIndex = 62;
            this.label16.Text = "Gesamtkosten";
            // 
            // lbl_gesamtkosten
            // 
            this.lbl_gesamtkosten.AutoSize = true;
            this.lbl_gesamtkosten.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gesamtkosten.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_gesamtkosten.Location = new System.Drawing.Point(832, 654);
            this.lbl_gesamtkosten.Name = "lbl_gesamtkosten";
            this.lbl_gesamtkosten.Size = new System.Drawing.Size(57, 25);
            this.lbl_gesamtkosten.TabIndex = 63;
            this.lbl_gesamtkosten.Text = "Leer!";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Gainsboro;
            this.label18.Location = new System.Drawing.Point(617, 608);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(452, 25);
            this.label18.TabIndex = 64;
            this.label18.Text = "________________________________________";
            // 
            // lbl_mwst
            // 
            this.lbl_mwst.AutoSize = true;
            this.lbl_mwst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mwst.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_mwst.Location = new System.Drawing.Point(832, 523);
            this.lbl_mwst.Name = "lbl_mwst";
            this.lbl_mwst.Size = new System.Drawing.Size(57, 25);
            this.lbl_mwst.TabIndex = 66;
            this.lbl_mwst.Text = "Leer!";
            this.lbl_mwst.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Gainsboro;
            this.label20.Location = new System.Drawing.Point(620, 523);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(104, 25);
            this.label20.TabIndex = 65;
            this.label20.Text = "MwsT(%):";
            // 
            // lbl_betrag
            // 
            this.lbl_betrag.AutoSize = true;
            this.lbl_betrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_betrag.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_betrag.Location = new System.Drawing.Point(832, 470);
            this.lbl_betrag.Name = "lbl_betrag";
            this.lbl_betrag.Size = new System.Drawing.Size(57, 25);
            this.lbl_betrag.TabIndex = 68;
            this.lbl_betrag.Text = "Leer!";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Gainsboro;
            this.label22.Location = new System.Drawing.Point(620, 470);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 25);
            this.label22.TabIndex = 67;
            this.label22.Text = "Betrag:";
            // 
            // lbl_versandkosten
            // 
            this.lbl_versandkosten.AutoSize = true;
            this.lbl_versandkosten.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_versandkosten.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_versandkosten.Location = new System.Drawing.Point(832, 583);
            this.lbl_versandkosten.Name = "lbl_versandkosten";
            this.lbl_versandkosten.Size = new System.Drawing.Size(57, 25);
            this.lbl_versandkosten.TabIndex = 70;
            this.lbl_versandkosten.Text = "Leer!";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Gainsboro;
            this.label24.Location = new System.Drawing.Point(620, 583);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(150, 25);
            this.label24.TabIndex = 69;
            this.label24.Text = "Versandkosten:";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(12, 636);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(602, 51);
            this.button1.TabIndex = 71;
            this.button1.Text = "Speichern";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HinzufügenRechnung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1049, 699);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_versandkosten);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.lbl_betrag);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.lbl_mwst);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_gesamtkosten);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbx_datum);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tbx_lieferung);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbx_betrag);
            this.Controls.Add(this.cbx_konto);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbx_mwstsatz);
            this.Controls.Add(this.cbx_mwst);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_stb);
            this.Controls.Add(this.cbx_status);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbx_zart);
            this.Controls.Add(this.cbx_zahlung);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cbx_bestellung);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbx_vkos);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbx_vart);
            this.Controls.Add(this.cbx_versand);
            this.Controls.Add(this.label1);
            this.Name = "HinzufügenRechnung";
            this.Text = "HinzufügenRechnung";
            this.Load += new System.EventHandler(this.HinzufügenRechnung_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_vart;
        private System.Windows.Forms.ComboBox cbx_versand;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_vkos;
        private System.Windows.Forms.ComboBox cbx_bestellung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbx_zart;
        private System.Windows.Forms.ComboBox cbx_zahlung;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_stb;
        private System.Windows.Forms.ComboBox cbx_status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbx_mwstsatz;
        private System.Windows.Forms.ComboBox cbx_mwst;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbx_konto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbx_betrag;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbx_lieferung;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbx_datum;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_gesamtkosten;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_mwst;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbl_betrag;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_versandkosten;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button1;
    }
}