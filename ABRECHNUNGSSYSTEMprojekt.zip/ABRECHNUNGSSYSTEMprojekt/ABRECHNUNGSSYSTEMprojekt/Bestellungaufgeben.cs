﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class Bestellungaufgeben : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";

        public Bestellungaufgeben()
        {
            InitializeComponent();
        }

        private void Bestellungaufgeben_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = connectionString;
                con.Open();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Datenbank-öffnungsfehler: " + ex.Message);
            }

            FillComboBoxes();
        }

        private void FillComboBoxes()
        {
            try
            {
                con.Open();

                FillComboBoxFromQuery("SELECT Kunden_id FROM Kunde ORDER BY Kunden_id ASC", cbx_kunden);
                FillComboBoxFromQuery("SELECT Zahlung_id FROM ZahlungArt ORDER BY Zahlung_id ASC", cbx_zahlung);
                FillComboBoxFromQuery("SELECT Artikel_id FROM Artikel ORDER BY Artikel_id ASC", cbx_artikel);
                FillComboBoxFromQuery("SELECT Rabatt_id FROM Rabatt ORDER BY Rabatt_id ASC", cbx_rabatt);

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Zugriff auf die Tabellen: " + ex.Message);
            }
        }

        private void FillComboBoxFromQuery(string query, ComboBox comboBox)
        {
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox.Items.Add(dr.GetInt32(0));
            }
            dr.Close();
        }

        private void cbx_kunden_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_kunden.SelectedItem.ToString());
                cmd = new OleDbCommand("select * from Kunde where Kunden_id =" + vergleich, con);
                dr = cmd.ExecuteReader();
                dr.Read();
                tbx_nach.Text = dr.GetString(3);
                tbx_vor.Text = dr.GetString(2);
                tbx_kundeadresse.Text = dr.GetString(4);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_zahlung_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_zahlung.SelectedItem.ToString());
                cmd = new OleDbCommand("select * from Zahlungart where Zahlung_id =" + vergleich, con);
                dr = cmd.ExecuteReader();
                dr.Read();
                tbx_zahlart.Text = dr.GetString(1);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_artikel_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_artikel.SelectedItem.ToString());
                cmd = new OleDbCommand("select * from Artikel where Artikel_id =" + vergleich, con);
                dr = cmd.ExecuteReader();
                dr.Read();
                tbx_artikel.Text = dr.GetString(2);
                tbx_preis.Text = dr.GetInt32(4).ToString(); // Änderung: Preis als Dezimalzahl
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_rabatt_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_rabatt.SelectedItem.ToString());
                cmd = new OleDbCommand("select * from Rabatt where Rabatt_id =" + vergleich, con);
                dr = cmd.ExecuteReader();
                dr.Read();
                tbx_rabatt.Text = dr.GetInt32(4).ToString(); // Änderung: Rabatt als Dezimalzahl
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        // Event-Handler für Änderungen in der TextBox tbx_preis
        private void Tbx_preis_TextChanged(object sender, EventArgs e)
        {
            BerechneUndZeigeZwischensumme();
        }

        // Event-Handler für Änderungen in der TextBox tbx_rabatt
        private void Tbx_rabatt_TextChanged(object sender, EventArgs e)
        {
            BerechneUndZeigeGesamtkosten();
        }

        // Methode zur Berechnung und Anzeige der Zwischensumme
        private void BerechneUndZeigeGesamtkosten()
        {
            if (decimal.TryParse(lbl_zwischensumme.Text, out decimal zwischensumme))
            {
                // Wenn tbx_rabatt nicht leer ist, wird der Rabatt berücksichtigt
                if (!string.IsNullOrWhiteSpace(tbx_rabatt.Text) && decimal.TryParse(tbx_rabatt.Text, out decimal rabatt))
                {
                    decimal gesamtkosten = zwischensumme - (zwischensumme * (rabatt / 100));
                    lbl_gesamtkosten.Text = gesamtkosten.ToString();
                    lbl_rabatt.Text = rabatt.ToString(); // Anzeigen des Rabatts in lbl_rabatt
                }
                else
                {
                    // Wenn kein Rabatt ausgewählt ist, wird nur die Zwischensumme als Gesamtkosten angezeigt
                    lbl_gesamtkosten.Text = zwischensumme.ToString();
                    lbl_rabatt.Text = "0"; // Anzeigen des Rabatts als 0 in lbl_rabatt
                }
            }
        }

        // Methode zur Berechnung und Anzeige der Gesamtkosten
        private void BerechneUndZeigeZwischensumme()
        {
            if (decimal.TryParse(tbx_preis.Text, out decimal preis))
            {
                lbl_zwischensumme.Text = preis.ToString(); // Korrektur: Verwende lbl_zwischensumme anstatt lbx_zwischensumme
                BerechneUndZeigeGesamtkosten();
            }
        }

        private void tbx_preis_TextChanged_1(object sender, EventArgs e)
        {
            BerechneUndZeigeZwischensumme();
        }

        private void tbx_rabatt_TextChanged_1(object sender, EventArgs e)
        {
            // Überprüfen, ob tbx_rabatt leer ist
            if (string.IsNullOrWhiteSpace(tbx_rabatt.Text))
            {
                // Wenn tbx_rabatt leer ist, soll der Wert auf 0 gesetzt werden
                lbl_rabatt.Text = "0";
            }
            else
            {
                // Wenn ein Wert in tbx_rabatt vorhanden ist, wird dieser in lbl_rabatt angezeigt
                lbl_rabatt.Text = tbx_rabatt.Text;
            }
            // Berechnung der Gesamtkosten
            BerechneUndZeigeGesamtkosten();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cbx_kunden.Text) || string.IsNullOrWhiteSpace(cbx_zahlung.Text)
                    )
            {
                MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
               
                MessageBox.Show("Erfolgreich");

                // Nach dem Einfügen der Bestellung die DataGridView aktualisieren

            }
        }
    }
}
