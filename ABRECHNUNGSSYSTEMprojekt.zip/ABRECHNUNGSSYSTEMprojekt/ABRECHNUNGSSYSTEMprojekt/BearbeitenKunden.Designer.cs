﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class BearbeitenKunden {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.tbx_punkte = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbx_rabatt = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tbx_password = new System.Windows.Forms.TextBox();
            this.tbx_benutzername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_adresse = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_nachname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_vorname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbx_zahl = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbx_punkte
            // 
            this.tbx_punkte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_punkte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_punkte.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_punkte.Location = new System.Drawing.Point(673, 243);
            this.tbx_punkte.Multiline = true;
            this.tbx_punkte.Name = "tbx_punkte";
            this.tbx_punkte.Size = new System.Drawing.Size(173, 29);
            this.tbx_punkte.TabIndex = 42;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(516, 246);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 20);
            this.label8.TabIndex = 41;
            this.label8.Text = "Punkte:";
            // 
            // cbx_rabatt
            // 
            this.cbx_rabatt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cbx_rabatt.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_rabatt.FormattingEnabled = true;
            this.cbx_rabatt.Location = new System.Drawing.Point(673, 190);
            this.cbx_rabatt.Name = "cbx_rabatt";
            this.cbx_rabatt.Size = new System.Drawing.Size(173, 21);
            this.cbx_rabatt.TabIndex = 40;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(516, 188);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 20);
            this.label7.TabIndex = 39;
            this.label7.Text = "Rabatt ID:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.Gainsboro;
            this.checkBox1.Location = new System.Drawing.Point(863, 126);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(146, 20);
            this.checkBox1.TabIndex = 38;
            this.checkBox1.Text = "Password Anzeigen";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tbx_password
            // 
            this.tbx_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_password.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_password.Location = new System.Drawing.Point(673, 123);
            this.tbx_password.Multiline = true;
            this.tbx_password.Name = "tbx_password";
            this.tbx_password.Size = new System.Drawing.Size(173, 29);
            this.tbx_password.TabIndex = 37;
            // 
            // tbx_benutzername
            // 
            this.tbx_benutzername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_benutzername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_benutzername.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_benutzername.Location = new System.Drawing.Point(673, 65);
            this.tbx_benutzername.Multiline = true;
            this.tbx_benutzername.Name = "tbx_benutzername";
            this.tbx_benutzername.Size = new System.Drawing.Size(173, 29);
            this.tbx_benutzername.TabIndex = 36;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(516, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 35;
            this.label5.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(516, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Benutzername";
            // 
            // tbx_adresse
            // 
            this.tbx_adresse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_adresse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_adresse.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_adresse.Location = new System.Drawing.Point(210, 243);
            this.tbx_adresse.Multiline = true;
            this.tbx_adresse.Name = "tbx_adresse";
            this.tbx_adresse.Size = new System.Drawing.Size(173, 29);
            this.tbx_adresse.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(41, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 20);
            this.label4.TabIndex = 32;
            this.label4.Text = "Kunden Adresse:";
            // 
            // tbx_nachname
            // 
            this.tbx_nachname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_nachname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_nachname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_nachname.Location = new System.Drawing.Point(210, 179);
            this.tbx_nachname.Multiline = true;
            this.tbx_nachname.Name = "tbx_nachname";
            this.tbx_nachname.Size = new System.Drawing.Size(173, 29);
            this.tbx_nachname.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(41, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Nachname";
            // 
            // tbx_vorname
            // 
            this.tbx_vorname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_vorname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_vorname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_vorname.Location = new System.Drawing.Point(210, 123);
            this.tbx_vorname.Multiline = true;
            this.tbx_vorname.Name = "tbx_vorname";
            this.tbx_vorname.Size = new System.Drawing.Size(173, 29);
            this.tbx_vorname.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(41, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 20);
            this.label2.TabIndex = 28;
            this.label2.Text = "Vorname";
            // 
            // cbx_zahl
            // 
            this.cbx_zahl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cbx_zahl.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_zahl.FormattingEnabled = true;
            this.cbx_zahl.Location = new System.Drawing.Point(210, 75);
            this.cbx_zahl.Name = "cbx_zahl";
            this.cbx_zahl.Size = new System.Drawing.Size(173, 21);
            this.cbx_zahl.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(41, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 26;
            this.label1.Text = "Zahlungs ID:";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(210, 362);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(636, 51);
            this.button1.TabIndex = 43;
            this.button1.Text = "Speichern";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BearbeitenKunden
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1038, 527);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbx_punkte);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbx_rabatt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.tbx_password);
            this.Controls.Add(this.tbx_benutzername);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbx_adresse);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_nachname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbx_vorname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbx_zahl);
            this.Controls.Add(this.label1);
            this.Name = "BearbeitenKunden";
            this.Text = "BearbeitenKunden";
            this.Load += new System.EventHandler(this.BearbeitenKunden_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_punkte;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbx_rabatt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox tbx_password;
        private System.Windows.Forms.TextBox tbx_benutzername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_adresse;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_nachname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_vorname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_zahl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}