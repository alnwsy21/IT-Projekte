﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class RechnungHInzufügen : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public RechnungHInzufügen()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void RechnungHInzufügen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            datagriedview();
            AdjustDataGridViewSize();
        }
        private void datagriedview()
        {
            try
            {
                con.Open();
                ds.Clear();

                ada = new OleDbDataAdapter("SELECT Rechnung_id, Versand_id, Bestellung_id, Zahlung_id, Status_id, Mwst_id, Konto_id, Betrag, Lieferung, Datum " +
                    "from Rechnung  ORDER BY Rechnung_id ASC ", con);
                ada.Fill(ds, "rechnung");


                dghinzufügen.DataSource = ds;
                dghinzufügen.DataMember = "rechnung";

                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler: " + a.Message);
            }
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dghinzufügen.AllowUserToAddRows = false;
            dghinzufügen.AllowUserToDeleteRows = false;
            dghinzufügen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dghinzufügen.RowHeadersVisible = false;
            dghinzufügen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dghinzufügen.MultiSelect = false;
            dghinzufügen.ReadOnly = true;
            dghinzufügen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dghinzufügen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dghinzufügen.DefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dghinzufügen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dghinzufügen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dghinzufügen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dghinzufügen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dghinzufügen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dghinzufügen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dghinzufügen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dghinzufügen.ScrollBars = ScrollBars.Both;
        }
        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dghinzufügen.Size = new Size(panelchildform.Width - 20, panelchildform.Height - 20);
            dghinzufügen.Location = new Point(10, 10);
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];
                HinzufügenRechnung hinzufügen = new HinzufügenRechnung();
                openchildform(hinzufügen);
            }
        }
    }
}
