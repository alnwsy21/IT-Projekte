﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class HinzufügenMitarbeiter : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        
        public HinzufügenMitarbeiter() {
            InitializeComponent();
        }

        private void HinzufügenMitarbeiter_Load(object sender, EventArgs e)
        {

            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            tbx_password.PasswordChar = '•'; // oder textBox1.PasswordChar = '.';
        }

        private void button1_Click(object sender, EventArgs e) {
                try {
                    using (OleDbConnection con = new OleDbConnection(connectionString)) {
                        con.Open();
                        if (string.IsNullOrWhiteSpace(tbx_vorname.Text) || string.IsNullOrWhiteSpace(tbx_nachname.Text)
                            || string.IsNullOrWhiteSpace(tbx_position.Text) || string.IsNullOrWhiteSpace(tbx_benutzername.Text) || string.IsNullOrWhiteSpace(tbx_password.Text)
                            || string.IsNullOrWhiteSpace(cbx_rechte.Text)) {

                            MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else {
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Mitarbeiter(Vorname, Nachname, Pos, Benutzername, Passwort, Rechte) " +
                                "VALUES (@vorname, @nachname, @pos, @benutzername, @passwort, @rechte)", con)) {

                                insertCmd.Parameters.AddWithValue("@vorname", tbx_vorname.Text);
                                insertCmd.Parameters.AddWithValue("@nachname", tbx_nachname.Text);
                                insertCmd.Parameters.AddWithValue("@pos", tbx_position.Text);
                                insertCmd.Parameters.AddWithValue("@benutzername", tbx_benutzername.Text);
                                insertCmd.Parameters.AddWithValue("@passwort", tbx_password.Text); // Korrigiertes Passwort
                                insertCmd.Parameters.AddWithValue("@rechte", cbx_rechte.Text);
                                insertCmd.ExecuteNonQuery();
                            }
                            MessageBox.Show("Erfolgreich");
                        }
                    }
                }
                catch (Exception ex) {
                    // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                    MessageBox.Show("Fehler beim Speichern der Daten: " + ex);
                }

        }

        private void tbx_password_TextChanged(object sender, EventArgs e) {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) {
            if (cbx_show.Checked ) {
                tbx_password.PasswordChar = '\0'; // Zeigt den Text in tbx_show sichtbar
                
            }
            else {
                tbx_password.PasswordChar = '•'; // Verdeckt den Text in tbx_show
               
            }
        }
    }
}
