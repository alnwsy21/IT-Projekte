﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class RechnungBearbeiten : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Tech.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public RechnungBearbeiten()
        {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void RechnungBearbeiten_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            LoadData();
            AdjustDataGridViewSize();
        }
        private void LoadData()
        {
            try
            {
                ds.Clear();

                using (OleDbDataAdapter ada = new OleDbDataAdapter("SELECT Rechnung_id, Versand_id, Bestellung_id, Zahlung_id, Status_id, Mwst_id, Konto_id, Betrag, Lieferung, Datum " +
                    "from Rechnung  ORDER BY Rechnung_id ASC", con))
                {
                    ada.Fill(ds, "rechnung");
                }

                dgbearbeiten.DataSource = ds;
                dgbearbeiten.DataMember = "rechnung";


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler bei: " + a.Message);
            }
            finally
            {
                con.Close();
            }

        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dgbearbeiten.AllowUserToAddRows = false;
            dgbearbeiten.AllowUserToDeleteRows = false;
            dgbearbeiten.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgbearbeiten.RowHeadersVisible = false;
            dgbearbeiten.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgbearbeiten.MultiSelect = false;
            dgbearbeiten.ReadOnly = true;
            dgbearbeiten.BackgroundColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dgbearbeiten.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dgbearbeiten.DefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dgbearbeiten.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgbearbeiten.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dgbearbeiten.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dgbearbeiten.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dgbearbeiten.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dgbearbeiten.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dgbearbeiten.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dgbearbeiten.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dgbearbeiten.Location = new Point(10, 10);
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Extrahiere die Daten aus der ausgewählten Zeile
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];
                string bestellung = selectedRow.Cells["Bestellung_id"].Value.ToString(); // Ersetze "Name_der_ArtikelSpalte" durch den tatsächlichen Namen der Spalte für den Artikel
                string versand = selectedRow.Cells["Versand_id"].Value.ToString(); // Ersetze "Name_der_Bestellungsspalte" durch den tatsächlichen Namen der Spalte für die Bestellung
                string zahlung = selectedRow.Cells["Zahlung_id"].Value.ToString(); // Ersetze "Name_der_RabattSpalte" durch den tatsächlichen Namen der Spalte für den Rabatt
                string status = selectedRow.Cells["Status_id"].Value.ToString(); // Ersetze "Name_der_PreisSpalte" durch den tatsächlichen Namen der Spalte für den Preis
                string mwst = selectedRow.Cells["Mwst_id"].Value.ToString(); // Ersetze "Name_der_MengeSpalte" durch den tatsächlichen Namen der Spalte für die Menge
                string konto = selectedRow.Cells["Konto_id"].Value.ToString(); 
                string betrag = selectedRow.Cells["Betrag"].Value.ToString(); 
                string leiferung = selectedRow.Cells["Lieferung"].Value.ToString(); 
                string datum = selectedRow.Cells["Datum"].Value.ToString(); 

                // Setze die Werte in die entsprechenden TextBoxen und ComboBoxen
                cbx_bestellung.Text = bestellung;
                cbx_versand.Text = versand;
                cbx_zahlung.Text = zahlung;
                cbx_status.Text = status;
                cbx_mwst.Text = mwst;
                cbx_konto.Text = konto;
                tbx_betrag.Text = betrag;
                tbx_lieferung.Text = leiferung;
                tbx_datum.Text = datum;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection con = new OleDbConnection(connectionString))
                {
                    con.Open();
                    if (string.IsNullOrWhiteSpace(tbx_betrag.Text) || string.IsNullOrWhiteSpace(tbx_datum.Text) || string.IsNullOrWhiteSpace(tbx_lieferung.Text))
                    {
                        MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        // Erhalte die Bestellpositions-ID aus der ausgewählten Zeile der DataGridView
                        int bestellpositionId = Convert.ToInt32(dgbearbeiten.SelectedRows[0].Cells["Rechnung_id"].Value);

                        string query = "UPDATE Rechnung SET Versand_id = ?, Bestellung_id = ?, Zahlung_id = ?, Status_id = ?, Mwst_id = ?, Konto_id = ?, Betrag = ?, Lieferung = ?, Datum = ?" +
               "WHERE Rechnung_id = ?";

                        using (OleDbCommand updateCmd = new OleDbCommand(query, con))
                        {
                            updateCmd.Parameters.AddWithValue("@versand", Convert.ToInt32(cbx_versand.Text));
                            updateCmd.Parameters.AddWithValue("@best", Convert.ToInt32(cbx_bestellung.Text));
                            updateCmd.Parameters.AddWithValue("@zahlung", Convert.ToInt32(cbx_zahlung.Text));
                            updateCmd.Parameters.AddWithValue("@status", Convert.ToInt32(cbx_status.Text));
                            updateCmd.Parameters.AddWithValue("@mwst", Convert.ToInt32(cbx_mwst.Text));
                            updateCmd.Parameters.AddWithValue("@konto", Convert.ToInt32(cbx_konto.Text));
                            updateCmd.Parameters.AddWithValue("@betrag", Convert.ToInt32(tbx_betrag.Text));
                            updateCmd.Parameters.AddWithValue("@liefrung", tbx_lieferung.Text);
                            updateCmd.Parameters.AddWithValue("@datum", tbx_datum.Text);
                            updateCmd.Parameters.AddWithValue("@Rechnung_id", bestellpositionId);

                            updateCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Erfolgreich");

                        // Nachdem die Daten erfolgreich bearbeitet wurden, lade die Daten erneut in die DataGridView
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Bearbeiten der Daten: " + ex.Message);
            }
        }
    }
}
