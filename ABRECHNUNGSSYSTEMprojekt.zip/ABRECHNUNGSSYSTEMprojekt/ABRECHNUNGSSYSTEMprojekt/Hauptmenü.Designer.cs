﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class Hauptmenü {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hauptmenü));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_beenden = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.panel_stammdaten = new System.Windows.Forms.Panel();
            this.btn_artikel = new System.Windows.Forms.Button();
            this.btn_kunden = new System.Windows.Forms.Button();
            this.btn_mitarbeiter = new System.Windows.Forms.Button();
            this.btn_stammdaten = new System.Windows.Forms.Button();
            this.panel_einkauf = new System.Windows.Forms.Panel();
            this.btn_rechn = new System.Windows.Forms.Button();
            this.btn_bestell = new System.Windows.Forms.Button();
            this.btn_bestellung = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelchildform = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel_stammdaten.SuspendLayout();
            this.panel_einkauf.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panel1.Controls.Add(this.btn_beenden);
            this.panel1.Controls.Add(this.btn_logout);
            this.panel1.Controls.Add(this.panel_stammdaten);
            this.panel1.Controls.Add(this.btn_stammdaten);
            this.panel1.Controls.Add(this.panel_einkauf);
            this.panel1.Controls.Add(this.btn_bestellung);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 822);
            this.panel1.TabIndex = 0;
            // 
            // btn_beenden
            // 
            this.btn_beenden.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_beenden.FlatAppearance.BorderSize = 0;
            this.btn_beenden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_beenden.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_beenden.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_beenden.Location = new System.Drawing.Point(0, 493);
            this.btn_beenden.Name = "btn_beenden";
            this.btn_beenden.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_beenden.Size = new System.Drawing.Size(261, 45);
            this.btn_beenden.TabIndex = 9;
            this.btn_beenden.Text = "Beenden";
            this.btn_beenden.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_beenden.UseVisualStyleBackColor = true;
            this.btn_beenden.Click += new System.EventHandler(this.button10_Click);
            this.btn_beenden.MouseLeave += new System.EventHandler(this.btn_beenden_MouseLeave);
            this.btn_beenden.MouseHover += new System.EventHandler(this.btn_beenden_MouseHover);
            // 
            // btn_logout
            // 
            this.btn_logout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_logout.FlatAppearance.BorderSize = 0;
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_logout.Location = new System.Drawing.Point(0, 448);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_logout.Size = new System.Drawing.Size(261, 45);
            this.btn_logout.TabIndex = 8;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.button4_Click);
            this.btn_logout.MouseLeave += new System.EventHandler(this.btn_logout_MouseLeave);
            this.btn_logout.MouseHover += new System.EventHandler(this.btn_logout_MouseHover);
            // 
            // panel_stammdaten
            // 
            this.panel_stammdaten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.panel_stammdaten.Controls.Add(this.btn_artikel);
            this.panel_stammdaten.Controls.Add(this.btn_kunden);
            this.panel_stammdaten.Controls.Add(this.btn_mitarbeiter);
            this.panel_stammdaten.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_stammdaten.Location = new System.Drawing.Point(0, 322);
            this.panel_stammdaten.Name = "panel_stammdaten";
            this.panel_stammdaten.Size = new System.Drawing.Size(261, 126);
            this.panel_stammdaten.TabIndex = 7;
            // 
            // btn_artikel
            // 
            this.btn_artikel.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_artikel.FlatAppearance.BorderSize = 0;
            this.btn_artikel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_artikel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_artikel.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_artikel.Location = new System.Drawing.Point(0, 80);
            this.btn_artikel.Name = "btn_artikel";
            this.btn_artikel.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_artikel.Size = new System.Drawing.Size(261, 40);
            this.btn_artikel.TabIndex = 9;
            this.btn_artikel.Text = "Artikel";
            this.btn_artikel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_artikel.UseVisualStyleBackColor = true;
            this.btn_artikel.Click += new System.EventHandler(this.btn_artikel_Click);
            this.btn_artikel.MouseLeave += new System.EventHandler(this.btn_artikel_MouseLeave);
            this.btn_artikel.MouseHover += new System.EventHandler(this.btn_artikel_MouseHover);
            // 
            // btn_kunden
            // 
            this.btn_kunden.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_kunden.FlatAppearance.BorderSize = 0;
            this.btn_kunden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kunden.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kunden.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_kunden.Location = new System.Drawing.Point(0, 40);
            this.btn_kunden.Name = "btn_kunden";
            this.btn_kunden.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_kunden.Size = new System.Drawing.Size(261, 40);
            this.btn_kunden.TabIndex = 7;
            this.btn_kunden.Text = "Kunden";
            this.btn_kunden.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_kunden.UseVisualStyleBackColor = true;
            this.btn_kunden.Click += new System.EventHandler(this.button8_Click);
            this.btn_kunden.MouseLeave += new System.EventHandler(this.btn_kunden_MouseLeave);
            this.btn_kunden.MouseHover += new System.EventHandler(this.btn_kunden_MouseHover);
            // 
            // btn_mitarbeiter
            // 
            this.btn_mitarbeiter.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_mitarbeiter.FlatAppearance.BorderSize = 0;
            this.btn_mitarbeiter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mitarbeiter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mitarbeiter.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_mitarbeiter.Location = new System.Drawing.Point(0, 0);
            this.btn_mitarbeiter.Name = "btn_mitarbeiter";
            this.btn_mitarbeiter.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_mitarbeiter.Size = new System.Drawing.Size(261, 40);
            this.btn_mitarbeiter.TabIndex = 6;
            this.btn_mitarbeiter.Text = "Mitarbeiter";
            this.btn_mitarbeiter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mitarbeiter.UseVisualStyleBackColor = true;
            this.btn_mitarbeiter.Click += new System.EventHandler(this.button7_Click);
            this.btn_mitarbeiter.MouseLeave += new System.EventHandler(this.btn_mitarbeiter_MouseLeave);
            this.btn_mitarbeiter.MouseHover += new System.EventHandler(this.btn_mitarbeiter_MouseHover);
            // 
            // btn_stammdaten
            // 
            this.btn_stammdaten.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_stammdaten.FlatAppearance.BorderSize = 0;
            this.btn_stammdaten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_stammdaten.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stammdaten.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_stammdaten.Location = new System.Drawing.Point(0, 277);
            this.btn_stammdaten.Name = "btn_stammdaten";
            this.btn_stammdaten.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_stammdaten.Size = new System.Drawing.Size(261, 45);
            this.btn_stammdaten.TabIndex = 6;
            this.btn_stammdaten.Text = "Stammdaten";
            this.btn_stammdaten.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_stammdaten.UseVisualStyleBackColor = true;
            this.btn_stammdaten.Click += new System.EventHandler(this.button3_Click);
            this.btn_stammdaten.MouseLeave += new System.EventHandler(this.btn_stammdaten_MouseLeave);
            this.btn_stammdaten.MouseHover += new System.EventHandler(this.button3_MouseHover);
            // 
            // panel_einkauf
            // 
            this.panel_einkauf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.panel_einkauf.Controls.Add(this.btn_rechn);
            this.panel_einkauf.Controls.Add(this.btn_bestell);
            this.panel_einkauf.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_einkauf.Location = new System.Drawing.Point(0, 173);
            this.panel_einkauf.Name = "panel_einkauf";
            this.panel_einkauf.Size = new System.Drawing.Size(261, 104);
            this.panel_einkauf.TabIndex = 3;
            // 
            // btn_rechn
            // 
            this.btn_rechn.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_rechn.FlatAppearance.BorderSize = 0;
            this.btn_rechn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rechn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rechn.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_rechn.Location = new System.Drawing.Point(0, 40);
            this.btn_rechn.Name = "btn_rechn";
            this.btn_rechn.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_rechn.Size = new System.Drawing.Size(261, 40);
            this.btn_rechn.TabIndex = 8;
            this.btn_rechn.Text = "Rechnung";
            this.btn_rechn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_rechn.UseVisualStyleBackColor = true;
            this.btn_rechn.Click += new System.EventHandler(this.button21_Click);
            this.btn_rechn.MouseLeave += new System.EventHandler(this.btn_rechn_MouseLeave);
            this.btn_rechn.MouseHover += new System.EventHandler(this.btn_rechn_MouseHover);
            // 
            // btn_bestell
            // 
            this.btn_bestell.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_bestell.FlatAppearance.BorderSize = 0;
            this.btn_bestell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bestell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bestell.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_bestell.Location = new System.Drawing.Point(0, 0);
            this.btn_bestell.Name = "btn_bestell";
            this.btn_bestell.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_bestell.Size = new System.Drawing.Size(261, 40);
            this.btn_bestell.TabIndex = 3;
            this.btn_bestell.Text = "Bestellung";
            this.btn_bestell.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bestell.UseVisualStyleBackColor = true;
            this.btn_bestell.Click += new System.EventHandler(this.button12_Click);
            this.btn_bestell.MouseLeave += new System.EventHandler(this.btn_bestell_MouseLeave);
            this.btn_bestell.MouseHover += new System.EventHandler(this.button12_MouseHover);
            // 
            // btn_bestellung
            // 
            this.btn_bestellung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.btn_bestellung.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_bestellung.FlatAppearance.BorderSize = 0;
            this.btn_bestellung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bestellung.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bestellung.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_bestellung.Location = new System.Drawing.Point(0, 128);
            this.btn_bestellung.Name = "btn_bestellung";
            this.btn_bestellung.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_bestellung.Size = new System.Drawing.Size(261, 45);
            this.btn_bestellung.TabIndex = 2;
            this.btn_bestellung.Text = "Bewegungsdaten";
            this.btn_bestellung.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bestellung.UseVisualStyleBackColor = false;
            this.btn_bestellung.Click += new System.EventHandler(this.button1_Click);
            this.btn_bestellung.MouseLeave += new System.EventHandler(this.btn_bestellung_MouseLeave);
            this.btn_bestellung.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(261, 128);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(248, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "Hauptmenü";
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panelchildform.Controls.Add(this.label2);
            this.panelchildform.Controls.Add(this.pictureBox1);
            this.panelchildform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelchildform.Location = new System.Drawing.Point(261, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1232, 822);
            this.panelchildform.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(234, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(901, 108);
            this.label2.TabIndex = 7;
            this.label2.Text = "Herzlich willkommen im Hauptmenü des \r\n               Abrechnungssystems!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(438, 307);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(365, 286);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Hauptmenü
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1493, 822);
            this.Controls.Add(this.panelchildform);
            this.Controls.Add(this.panel1);
            this.Name = "Hauptmenü";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hauptmenü";
            this.Load += new System.EventHandler(this.Hauptmenü_Load);
            this.panel1.ResumeLayout(false);
            this.panel_stammdaten.ResumeLayout(false);
            this.panel_einkauf.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelchildform.ResumeLayout(false);
            this.panelchildform.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_beenden;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Panel panel_stammdaten;
        private System.Windows.Forms.Button btn_artikel;
        private System.Windows.Forms.Button btn_kunden;
        private System.Windows.Forms.Button btn_mitarbeiter;
        private System.Windows.Forms.Button btn_stammdaten;
        private System.Windows.Forms.Panel panel_einkauf;
        private System.Windows.Forms.Button btn_bestell;
        private System.Windows.Forms.Button btn_bestellung;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_rechn;
    }
}