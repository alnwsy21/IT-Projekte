﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class KundenAnzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public KundenAnzeigen() {
            InitializeComponent();
            CustomizeDataGridView();
        }

        private void KundenAnzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("select Kunden_id, Zahlung_id, Kunden_vorname, Kunden_nachname, Kunden_adresse, Kunden_benutzername, Kunden_password, Rabatt_id, Punkte from Kunde", con);
                ada.Fill(ds, "kunden");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "kunden";
                con.Close();
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
            AdjustDataGridViewSize();
        }
        private void CustomizeDataGridView()
        {
            // DataGridView-Eigenschaften anpassen
            dganzeigen.AllowUserToAddRows = false;
            dganzeigen.AllowUserToDeleteRows = false;
            dganzeigen.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dganzeigen.RowHeadersVisible = false;
            dganzeigen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dganzeigen.MultiSelect = false;
            dganzeigen.ReadOnly = true;
            dganzeigen.BackgroundColor = Color.FromArgb(21, 21, 21);
            dganzeigen.GridColor = Color.FromArgb(32, 32, 32);

            // Zellformatierung
            dganzeigen.DefaultCellStyle.BackColor = Color.FromArgb(21, 21, 21);
            dganzeigen.DefaultCellStyle.ForeColor = Color.White;
            dganzeigen.DefaultCellStyle.Font = new Font("Arial", 9);

            // Kopfzeile anpassen
            dganzeigen.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);
            dganzeigen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dganzeigen.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dganzeigen.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Auswahlstil
            dganzeigen.DefaultCellStyle.SelectionBackColor = Color.FromArgb(32, 32, 32);
            dganzeigen.DefaultCellStyle.SelectionForeColor = Color.White;

            // Alternierende Zeilenfarbe
            dganzeigen.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(32, 32, 32);

            // Gitterlinien anzeigen
            dganzeigen.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Scrollbar anpassen
            dganzeigen.ScrollBars = ScrollBars.Both;
        }


        private void AdjustDataGridViewSize()
        {
            // DataGridView an die Größe des Panels anpassen
            dganzeigen.Size = new Size(panel1.Width - 20, panel1.Height - 20);
            dganzeigen.Location = new Point(10, 10);
        }
    }
}
