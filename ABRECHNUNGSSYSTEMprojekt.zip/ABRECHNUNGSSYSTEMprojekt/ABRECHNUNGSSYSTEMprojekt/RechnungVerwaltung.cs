﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ABRECHNUNGSSYSTEMprojekt
{
    public partial class RechnungVerwaltung : Form
    {
        public RechnungVerwaltung()
        {
            InitializeComponent();
        }
        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
            {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void btn_anzeigen_Click(object sender, EventArgs e)
        {
            openchildform(new RechnungAnzeigen());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openchildform(new RechnungHInzufügen());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openchildform(new RechnungBearbeiten());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openchildform(new RechnungEntfernen());
        }
    }
}
