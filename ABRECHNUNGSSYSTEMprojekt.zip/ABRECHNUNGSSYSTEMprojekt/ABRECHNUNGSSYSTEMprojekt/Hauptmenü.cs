﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace ABRECHNUNGSSYSTEMprojekt {
    public partial class Hauptmenü : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        // private string benutzername;
        // private string password;
        private string username;
        private string password;
        public Hauptmenü(string username, string password) {
            InitializeComponent();
            customsizedesign();
            this.username = username;
            this.password = password;
        }
  
        private void customsizedesign() {
            panel_einkauf.Visible = false;
         
            panel_stammdaten.Visible = false;
        }
        private void hidesubmenu() {
            if (panel_einkauf.Visible == true) {
                panel_einkauf.Visible = false;
            }
         
            if (panel_stammdaten.Visible == true) {
                panel_stammdaten.Visible = false;
            }
        }

        private void showsubmenu(Panel submenu) {
            if (submenu.Visible == false) {
                hidesubmenu();
                submenu.Visible = true;
            }
            else {
                submenu.Visible = false;
            }
        }

        private Form activeform = null;
        private void openchildform(Form childform) {
            if (activeform != null) {
                activeform.Close();
            }

            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelchildform.Controls.Add(childform);
            panelchildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void Hauptmenü_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Tech.accdb";

                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e) {
            showsubmenu(panel_einkauf);
            
        }

        private void button3_Click(object sender, EventArgs e) {
            showsubmenu(panel_stammdaten);
        }

 
        private void btn_artikel_Click(object sender, EventArgs e) {
            openchildform(new ArtikelVerwaltung());
            hidesubmenu();
        }

        private void button9_Click(object sender, EventArgs e) {

        }

        private void button8_Click(object sender, EventArgs e) {
            openchildform(new Kundenverwaltung());
            hidesubmenu();
        }

        private void button7_Click(object sender, EventArgs e) {
            try {
                con.Open();
                cmd = new OleDbCommand("SELECT COUNT(*) FROM Mitarbeiter WHERE Benutzername = @username AND Passwort = @password AND Rechte = 'Admin'", con);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                int adminCount = (int)cmd.ExecuteScalar();

                if (adminCount > 0) {
                    
                    openchildform(new Mitarbeiterverwaltung());
                    hidesubmenu();
                }
                else {
                    MessageBox.Show("Sie haben keine Berechtigung für diese Aktion.");
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler bei der Anmeldung: " + ex.Message);
            }
            finally {
                con.Close(); // Verbindung schließen
            }

        }

   

        private void lbl_nummer_Click(object sender, EventArgs e) {

        }

        private void lbl_rechte_Click(object sender, EventArgs e) {

        }

        private void button1_MouseHover(object sender, EventArgs e) {
            btn_bestellung.BackColor = Color.Red;
        }

        private void button3_MouseHover(object sender, EventArgs e) {
            btn_stammdaten.BackColor = Color.Red;
        }

        private void btn_stammdaten_MouseLeave(object sender, EventArgs e) {
            btn_stammdaten.BackColor = Color.FromArgb(21, 21, 21);
        }

        private void btn_bestellung_MouseLeave(object sender, EventArgs e) {
            btn_bestellung.BackColor = Color.FromArgb(21, 21, 21);
        }

        private void btn_logout_MouseHover(object sender, EventArgs e) {
            btn_logout.BackColor = Color.Red;
        }

        private void btn_beenden_MouseHover(object sender, EventArgs e) {
            btn_beenden.BackColor = Color.Red;
        }

        private void btn_logout_MouseLeave(object sender, EventArgs e) {
            btn_logout.BackColor = Color.FromArgb(21, 21, 21);
        }

        private void btn_beenden_MouseLeave(object sender, EventArgs e) {
            btn_beenden.BackColor = Color.FromArgb(21, 21, 21);
        }

        private void btn_mitarbeiter_MouseHover(object sender, EventArgs e) {
            btn_mitarbeiter.BackColor = Color.Red;
        }

        private void btn_mitarbeiter_MouseLeave(object sender, EventArgs e) {
            btn_mitarbeiter.BackColor = Color.FromArgb(32, 32, 32);
        }

        private void btn_kunden_MouseHover(object sender, EventArgs e) {
            btn_kunden.BackColor = Color.Red;
        }

        private void btn_kunden_MouseLeave(object sender, EventArgs e) {
            btn_kunden.BackColor = Color.FromArgb(32, 32, 32);
        }

        private void btn_artikel_MouseHover(object sender, EventArgs e) {
            btn_artikel.BackColor = Color.Red;
        }

        private void btn_artikel_MouseLeave(object sender, EventArgs e) {
            btn_artikel.BackColor = Color.FromArgb(32, 32, 32);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            openchildform(new BestellungVerwaltung());
            hidesubmenu();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            openchildform(new RechnungVerwaltung());
            hidesubmenu();
        }

        private void button12_MouseHover(object sender, EventArgs e)
        {
            btn_bestell.BackColor = Color.Red;
        }

        private void btn_bestell_MouseLeave(object sender, EventArgs e)
        {
            btn_bestell.BackColor = Color.FromArgb(32, 32, 32);
        }

        private void btn_rechn_MouseHover(object sender, EventArgs e)
        {
            btn_rechn.BackColor = Color.Red;
        }

        private void btn_rechn_MouseLeave(object sender, EventArgs e)
        {
            btn_rechn.BackColor = Color.FromArgb(32, 32, 32);
        }
    }
}
