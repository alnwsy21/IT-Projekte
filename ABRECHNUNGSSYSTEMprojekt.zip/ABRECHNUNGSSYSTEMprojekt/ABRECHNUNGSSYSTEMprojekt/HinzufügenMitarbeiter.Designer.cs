﻿
namespace ABRECHNUNGSSYSTEMprojekt {
    partial class HinzufügenMitarbeiter {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbx_vorname = new System.Windows.Forms.TextBox();
            this.tbx_nachname = new System.Windows.Forms.TextBox();
            this.tbx_position = new System.Windows.Forms.TextBox();
            this.tbx_benutzername = new System.Windows.Forms.TextBox();
            this.tbx_password = new System.Windows.Forms.TextBox();
            this.cbx_show = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbx_rechte = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(51, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vorname";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(51, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nachname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(51, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "position";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(566, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Benutzername";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(566, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Password";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(190, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(647, 51);
            this.button1.TabIndex = 7;
            this.button1.Text = "Speichern";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbx_vorname
            // 
            this.tbx_vorname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_vorname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_vorname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_vorname.Location = new System.Drawing.Point(157, 54);
            this.tbx_vorname.Multiline = true;
            this.tbx_vorname.Name = "tbx_vorname";
            this.tbx_vorname.Size = new System.Drawing.Size(173, 29);
            this.tbx_vorname.TabIndex = 8;
            // 
            // tbx_nachname
            // 
            this.tbx_nachname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_nachname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_nachname.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_nachname.Location = new System.Drawing.Point(157, 114);
            this.tbx_nachname.Multiline = true;
            this.tbx_nachname.Name = "tbx_nachname";
            this.tbx_nachname.Size = new System.Drawing.Size(173, 29);
            this.tbx_nachname.TabIndex = 9;
            // 
            // tbx_position
            // 
            this.tbx_position.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_position.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_position.Location = new System.Drawing.Point(157, 179);
            this.tbx_position.Multiline = true;
            this.tbx_position.Name = "tbx_position";
            this.tbx_position.Size = new System.Drawing.Size(173, 29);
            this.tbx_position.TabIndex = 10;
            // 
            // tbx_benutzername
            // 
            this.tbx_benutzername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_benutzername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_benutzername.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_benutzername.Location = new System.Drawing.Point(686, 49);
            this.tbx_benutzername.Multiline = true;
            this.tbx_benutzername.Name = "tbx_benutzername";
            this.tbx_benutzername.Size = new System.Drawing.Size(173, 29);
            this.tbx_benutzername.TabIndex = 11;
            // 
            // tbx_password
            // 
            this.tbx_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.tbx_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_password.ForeColor = System.Drawing.Color.Gainsboro;
            this.tbx_password.Location = new System.Drawing.Point(686, 114);
            this.tbx_password.Multiline = true;
            this.tbx_password.Name = "tbx_password";
            this.tbx_password.Size = new System.Drawing.Size(173, 29);
            this.tbx_password.TabIndex = 12;
            this.tbx_password.TextChanged += new System.EventHandler(this.tbx_password_TextChanged);
            // 
            // cbx_show
            // 
            this.cbx_show.AutoSize = true;
            this.cbx_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_show.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_show.Location = new System.Drawing.Point(876, 117);
            this.cbx_show.Name = "cbx_show";
            this.cbx_show.Size = new System.Drawing.Size(146, 20);
            this.cbx_show.TabIndex = 14;
            this.cbx_show.Text = "Password Anzeigen";
            this.cbx_show.UseVisualStyleBackColor = true;
            this.cbx_show.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(566, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Rechte";
            // 
            // cbx_rechte
            // 
            this.cbx_rechte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.cbx_rechte.ForeColor = System.Drawing.Color.Gainsboro;
            this.cbx_rechte.FormattingEnabled = true;
            this.cbx_rechte.Items.AddRange(new object[] {
            "Admin",
            "Benutzer"});
            this.cbx_rechte.Location = new System.Drawing.Point(686, 184);
            this.cbx_rechte.Name = "cbx_rechte";
            this.cbx_rechte.Size = new System.Drawing.Size(173, 21);
            this.cbx_rechte.TabIndex = 15;
            // 
            // HinzufügenMitarbeiter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1038, 527);
            this.Controls.Add(this.cbx_rechte);
            this.Controls.Add(this.cbx_show);
            this.Controls.Add(this.tbx_password);
            this.Controls.Add(this.tbx_benutzername);
            this.Controls.Add(this.tbx_position);
            this.Controls.Add(this.tbx_nachname);
            this.Controls.Add(this.tbx_vorname);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "HinzufügenMitarbeiter";
            this.Text = "HinzufügenMitarbeiter";
            this.Load += new System.EventHandler(this.HinzufügenMitarbeiter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbx_vorname;
        private System.Windows.Forms.TextBox tbx_nachname;
        private System.Windows.Forms.TextBox tbx_position;
        private System.Windows.Forms.TextBox tbx_benutzername;
        private System.Windows.Forms.TextBox tbx_password;
        private System.Windows.Forms.CheckBox cbx_show;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbx_rechte;
    }
}