﻿
namespace ABRECHNUNGSSYSTEMprojekt
{
    partial class RechnungHInzufügen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelchildform = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dghinzufügen = new System.Windows.Forms.DataGridView();
            this.panelchildform.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelchildform
            // 
            this.panelchildform.Controls.Add(this.panel1);
            this.panelchildform.Location = new System.Drawing.Point(0, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(1049, 699);
            this.panelchildform.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dghinzufügen);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1046, 340);
            this.panel1.TabIndex = 0;
            // 
            // dghinzufügen
            // 
            this.dghinzufügen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.dghinzufügen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dghinzufügen.Location = new System.Drawing.Point(0, 0);
            this.dghinzufügen.Name = "dghinzufügen";
            this.dghinzufügen.RowHeadersWidth = 51;
            this.dghinzufügen.Size = new System.Drawing.Size(1043, 337);
            this.dghinzufügen.TabIndex = 0;
            this.dghinzufügen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dghinzufügen_CellDoubleClick);
            // 
            // RechnungHInzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.ClientSize = new System.Drawing.Size(1044, 696);
            this.Controls.Add(this.panelchildform);
            this.Name = "RechnungHInzufügen";
            this.Text = "RechnungHInzufügen";
            this.Load += new System.EventHandler(this.RechnungHInzufügen_Load);
            this.panelchildform.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dghinzufügen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dghinzufügen;
    }
}